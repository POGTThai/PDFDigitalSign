﻿Imports System.Data.OleDb
Imports System.IO
Imports System.Web.Services.Protocols
Imports System
Imports BarcodeLib.Barcode
Public Class clsThaiLifeV2
    Private Ssql As String = ""
    Private mdtAgent As DataTable
    Private msgTitle As String
    Private msgDesc As String

    Private ReportServer As String


    Private rsExec As New ReportExecution2005.ReportExecutionService()
    Public Function StartProcess(ByVal ReportName As String, ByVal PDFFileName As String) As Boolean

        InitReportingWebServices(ReportName, PDFFileName)

        Return True
    End Function


    Private Function UpdateDatabase(ByVal strUpdateSQL As String) As Boolean

        Dim blnResult As Boolean = True
        Dim sqlCmd As SqlClient.SqlCommand


        Dim sqlconn As New SqlClient.SqlConnection
        sqlconn = modMain.KDB.GetDBConnection



        If strUpdateSQL <> "" Then
            sqlCmd = New SqlClient.SqlCommand(strUpdateSQL, sqlconn)
            Try
                sqlCmd.ExecuteNonQuery()
            Catch ex As Exception
                WriteLogFile("UpdateDatabase", "Error in updating database -" & vbCrLf & strUpdateSQL & " ", ex.Message.ToString)
                blnResult = False
            End Try
        End If

ExitFunc:
        If sqlCmd IsNot Nothing Then sqlCmd.Dispose()
        sqlCmd = Nothing
        sqlconn.Close()
        sqlconn.Dispose()

        Return blnResult
    End Function

    Private Sub InitReportingWebServices(ByVal RptName As String, ByVal PDFFileName As String)

        Dim bResult As Boolean = True


        Dim str_report_path As String = ""
        Dim str_report_folder As String = ""
        Dim str_report_name As String = ""
        Dim str_Pdf_filename As String = ""

        '//Create a new proxy to the web service
        Dim v_report_server As String = modMain.ReportServer

        '// Authenticate to the Web service using Windows credentials
        rsExec.Credentials = System.Net.CredentialCache.DefaultCredentials
        '// Assign the URL of the Web service

        rsExec.Url = v_report_server & "/reportexecution2005.asmx?wsdl"



        str_report_path = ""
        str_report_folder = ""
        str_report_name = ""
        str_Pdf_filename = ""


        str_report_folder = modMain.PDFFolder
        '------
        str_report_name = RptName.ToUpper

        If str_report_folder <> "" And str_report_name <> "" Then
            str_report_path = "/" & str_report_folder & "/" & str_report_name

            str_Pdf_filename = PDFFileName
            bResult = CallReport(str_report_path, str_Pdf_filename)
        End If

        If Not rsExec Is Nothing Then rsExec.Dispose()
        rsExec = Nothing

    End Sub
    Private Sub GetReportParameter(ByVal v_report_path As String)
        Dim str_report_server As String = modMain.ReportServer

        Dim rs As New ReportService2005.ReportingService2005()
        rs.Credentials = System.Net.CredentialCache.DefaultCredentials

        '// Assign the URL of the Web service
        rs.Url = str_report_server & "/reportservice2005.asmx?wsdl"
        rs.Url = "http://ipaddress/reportserver/reportservice2005.asmx?wsdl"

        '// Define variables needed for GetParameters() method
        '// Get the report name

        Dim _reportName As String = v_report_path
        Dim _historyid As String = Nothing
        Dim _forRendering As Boolean = False
        Dim _values As ReportService2005.ParameterValue() = Nothing
        Dim _credentials As ReportService2005.DataSourceCredentials() = Nothing
        Dim _parameters As ReportService2005.ReportParameter() = Nothing


        Try
            _parameters = rs.GetReportParameters(_reportName, _historyid, _forRendering, _values, _credentials)

            '//debug report parameter
            If Not (_parameters Is Nothing) Then
                Dim rp As ReportService2005.ReportParameter
                For Each rp In _parameters
                    Console.WriteLine("Name: {0}", rp.Name)
                Next rp
            End If


        Catch e As SoapException
            Console.WriteLine(e.Detail.InnerXml.ToString())
        End Try



    End Sub



    Private Function CallReport(ByVal v_report_path As String, _
                                ByVal v_Pdf_filename As String) As Boolean

        CallReport = True


        '// Prepare Render arguments
        Dim results() As Byte = Nothing
        Dim historyid As String = Nothing
        Dim format As String = "PDF"
        Dim devinfo As String = "<DeviceInfo><Toolbar>False</Toolbar></DeviceInfo>"


        '// Default Path;
        Dim Filename As String = v_Pdf_filename

        '// Get the report name

        Dim _reportName As String = v_report_path
        Try

            '// Load the selected report.
            Dim credentials As ReportExecution2005.DataSourceCredentials() = Nothing

            Dim showHideToggle As String = Nothing
            Dim encoding As String = ""
            Dim mimetype As String = ""
            Dim warnings As ReportExecution2005.Warning() = Nothing

            Dim reportHistoryParameters As ReportExecution2005.ParameterValue() = Nothing

            Dim streamid As String() = Nothing

            Dim execInfo As New ReportExecution2005.ExecutionInfo

            Dim execHeader As New ReportExecution2005.ExecutionHeader()

            Dim SessionId As String
            Dim extension As String = ""




            rsExec.ExecutionHeaderValue = execHeader

            execInfo = rsExec.LoadReport(_reportName, historyid)
            '// Prepare report parameter
            '// Set the parameters for the report needed.
            Dim parameters(0) As ReportExecution2005.ParameterValue 'hardcode no. of parameter
            parameters(0) = New ReportExecution2005.ParameterValue()
            parameters(0).Name = "AppNo"
            parameters(0).Value = modMain.AppNo
            'Write the parameters and values to logfile

            rsExec.SetExecutionParameters(parameters, "en-us")
            SessionId = rsExec.ExecutionHeaderValue.ExecutionID
            Console.WriteLine("SessionID: {0}", rsExec.ExecutionHeaderValue.ExecutionID)

            Try

                results = rsExec.Render(format, devinfo, extension, encoding, mimetype, warnings, streamid)
                execInfo = rsExec.GetExecutionInfo()



            Catch e As SoapException
                Console.WriteLine(e.Detail.OuterXml)

                CallReport = False
            End Try


            '// Create a file stream and write the report to it
            Dim stream As FileStream = File.Create(Filename, results.Length)
            stream.Write(results, 0, results.Length)
            stream.Close()
            stream = Nothing




        Catch ex As Exception
            logWriter.WriteLine("")
            logWriter.WriteLine(vbTab & vbTab & "Error calling Report" & ex.ToString)
            logWriter.WriteLine("")

            CallReport = False
        End Try


    End Function

End Class
