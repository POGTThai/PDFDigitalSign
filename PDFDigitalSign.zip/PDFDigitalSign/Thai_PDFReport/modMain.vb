﻿
Imports System.Windows.Forms
Imports System.Text


Module modMain

    Public KDB As PnDat03.GBSDbOperation    'Sql Database

    Public mtx As System.Threading.Mutex
    Public SharedResource As String
    Public fMain As frmMain
    Public logWriter As System.IO.StreamWriter

    Private prp_ProgId As String
    Private prp_Client As String
    Private prp_PDF As String

    Private prp_QPathName As String = ""
    Private prp_ReportServer As String = ""

    Private prp_PDFOutput As String
    Private prp_PDFFixForm As String
    Private prp_GSBServerPath As String
    Private prp_PDFFolder As String
    Private prp_AppNo As String = ""
    Private prp_TemplateName As String = ""
    Private prp_RequestID As String = ""


    Private prp_ImageSignPath As String
    Private prp_CertificatePath As String
    Private prp_CertificatePass As String
    Private prp_DigitalSignFlag As String
    Private prp_ServerPath_Subfolder As String
    Private prp_ServerPath_SubfolderByJobId As String


    Private prp_SplitBySubClassFolderFlag As String
    Private prp_SplitSubClassDestination As String



    Public Sub Main()
        Dim AppPath As String = System.AppDomain.CurrentDomain.BaseDirectory.Trim
        Dim TempStr As String = ""
        Dim Ds As System.Data.DataSet = Nothing
        Dim LocalRes As PnDat03.GBSLocalRes

        'On Error GoTo Hell

        Try
            'Open Local Resource File
            LocalRes = New PnDat03.GBSLocalRes


            If Not LocalRes.OpenResFile(AppPath & "test.res", "sss") Then
                If MultipleLocalRes(AppPath & "test.res") Then
                    If Not LocalRes.OpenResFile(AppPath & "test.res", "sss") Then GoTo ExitSub
                Else
                    GoTo ExitSub
                End If
            End If

            LocalRes.GetResValue("SharedResource", "FileName", TempStr)
            SharedResource = TempStr.Trim
            LocalRes.CloseDB()


            'SharedPelican Resource File
            KDB = New PnDat03.GBSDbOperation
            If Not KDB.OpenResFile(SharedResource, "ss") Then
                If MultipleSharedRes(SharedResource) Then
                    If Not KDB.OpenResFile(SharedResource, "sss") Then GoTo ExitSub
                Else
                    GoTo ExitSub
                End If
            End If

            'SSRS
            KDB.GetResValue("ReportServer", "ServerName", prp_ReportServer)
            prp_ReportServer = prp_ReportServer.Trim

            'QPathName

            prp_QPathName = ""
            KDB.GetResValue("PDFQueue", "QPath", prp_QPathName)
            prp_QPathName = prp_QPathName.Trim

            fMain = New frmMain
            Application.Run(fMain)

        Catch ex As Exception
            MessageBox.Show(ex.Message.ToString)
        End Try

ExitSub:
        Ds = Nothing
        LocalRes = Nothing

        DisposeObjects()
    End Sub

    Private Function PrevInstance(ByVal vAppName As String) As Boolean
        Dim bCreated As Boolean

        mtx = New System.Threading.Mutex(False, vAppName, bCreated)

        Return Not bCreated
    End Function

    Public Function MultipleLocalRes(ByVal vLocalResPath As String) As Boolean
        On Error GoTo Hell

        Dim strLocalResPath As String
        Dim strBackupResPath As String

        Dim lngStart As Integer

        Dim blnSuccess As Boolean

        blnSuccess = False
        MultipleLocalRes = False
        strLocalResPath = vLocalResPath.Trim
        strBackupResPath = BackupResFile(strLocalResPath, "multires")
        lngStart = strBackupResPath.Length

        While Not blnSuccess
            If Mid(strBackupResPath, lngStart, 1) = "." Then
                strBackupResPath = Left(strBackupResPath, lngStart)
                blnSuccess = True
            Else
                lngStart = lngStart - 1
                blnSuccess = (lngStart = 0)
            End If
        End While

        If Dir(strBackupResPath & "ini") = "" Then
            If Dir(strBackupResPath & "res") = "" Then
                GoTo ExitFunction
            Else
                strBackupResPath = strBackupResPath & "res"
            End If
        Else
            strBackupResPath = strBackupResPath & "ini"

            blnSuccess = False
            lngStart = Len(strLocalResPath)
            While Not blnSuccess
                If Mid(strLocalResPath, lngStart, 1) = "." Then
                    strLocalResPath = Left(strLocalResPath, lngStart) & "ini"
                    blnSuccess = True
                Else
                    lngStart = lngStart - 1
                    blnSuccess = (lngStart = 0)
                End If
            End While
        End If
        FileCopy(strBackupResPath, strLocalResPath)

        MultipleLocalRes = True

        GoTo ExitFunction

Hell:


ExitFunction:
        On Error GoTo 0
    End Function

    Private Function BackupResFile(ByVal vResPath As String, _
                                    ByVal vBackupFolder As String) As String
        On Error GoTo Hell

        Dim strBackupResPath As String
        Dim strBackupFolder As String
        Dim strResPath As String

        Dim blnSuccess As Boolean

        Dim iPost As Short

        strBackupResPath = ""
        strResPath = vResPath.Trim
        strBackupFolder = vBackupFolder.Trim

        If strResPath = "" Then GoTo ExitFunction
        If strBackupFolder = "" Then GoTo ExitFunction

        strBackupFolder = strBackupFolder.TrimStart("\")
        If Not strBackupFolder.EndsWith("\") Then
            strBackupFolder &= "\"
        End If

        iPost = vResPath.LastIndexOf("\")
        If iPost > 0 Then
            strBackupResPath = strResPath.Insert(iPost + 1, strBackupFolder)
        End If

Hell:


ExitFunction:
        Return strBackupResPath
    End Function

    Public Function MultipleSharedRes(ByVal vSharedResPath As String) As Boolean
        On Error GoTo Hell

        Dim strSharedResPath As String
        Dim strBackupResPath As String

        MultipleSharedRes = False
        strSharedResPath = vSharedResPath.Trim
        strBackupResPath = BackupResFile(strSharedResPath, "multires")

        If Dir(strBackupResPath) = "" Then
            Throw New System.ApplicationException("File (" & strBackupResPath & ") not Found!!")
        End If

        FileCopy(strBackupResPath, strSharedResPath)

        MultipleSharedRes = True

        GoTo ExitFunction

Hell:


ExitFunction:
        On Error GoTo 0
    End Function

    Public Sub DisposeObjects()
        On Error Resume Next

        KDB.CloseDB()
        KDB = Nothing
        End

        On Error GoTo 0
    End Sub

    Public Sub WriteLogFile(ByVal strLabel As String, ByVal strMessage As String, ByVal strErrMsg As String)
        Dim strBldr As New StringBuilder
        Dim intRetry As Integer = 0

Retry:
        Try
            intRetry += 1
            strBldr.Append(DateTime.Now.ToString("dd-MM-yyyy h:mm:ss tt", New System.Globalization.CultureInfo("en-US")))
            strBldr.Append(" --- ")
            If strLabel <> "" Then strBldr.Append("<" & strLabel & ">")
            strBldr.Append(" " & strMessage)
            If strErrMsg <> "" Then strBldr.Append(" : " & strErrMsg)

            logWriter.WriteLine(strBldr.ToString)
            intRetry = -1
            strBldr.Clear()
            strBldr = Nothing
        Catch ex As Exception

        End Try

        If intRetry <= 5 And intRetry <> -1 Then GoTo Retry

    End Sub

    Public ReadOnly Property QPathName As String
        Get
            Return prp_QPathName
        End Get

    End Property

    Public ReadOnly Property ReportServer As String
        Get
            Return prp_ReportServer
        End Get

    End Property

    Public Property ProgramId As String
        Set(value As String)
            prp_ProgId = value
        End Set
        Get
            Return prp_ProgId
        End Get
    End Property

    Public Property Client As String
        Set(value As String)
            prp_Client = value
        End Set
        Get
            Return prp_Client
        End Get
    End Property

    Public Property PDFFilename As String
        Set(value As String)
            prp_PDF = value
        End Set
        Get
            Return prp_PDF
        End Get
    End Property

    Public Property PDFOutput As String
        Set(value As String)
            prp_PDFOutput = value
        End Set
        Get
            Return prp_PDFOutput
        End Get
    End Property
    Public Property SplitSubClassDestination As String
        Set(value As String)
            prp_SplitSubClassDestination = value
        End Set
        Get
            Return prp_SplitSubClassDestination
        End Get
    End Property

    Public Property SplitBySubClassFolderFlag As String
        Set(value As String)
            prp_SplitBySubClassFolderFlag = value
        End Set
        Get
            Return prp_SplitBySubClassFolderFlag
        End Get
    End Property
    Public Property ServerPath_SubFolder As String
        Set(value As String)
            prp_ServerPath_Subfolder = value
        End Set
        Get
            Return prp_ServerPath_Subfolder
        End Get
    End Property
    Public Property ServerPath_SubFolderByJobId As String
        Set(value As String)
            prp_ServerPath_SubfolderByJobId = value
        End Set
        Get
            Return prp_ServerPath_SubfolderByJobId
        End Get
    End Property
    Public Property DigitalSignFlag As String
        Set(value As String)
            prp_DigitalSignFlag = value
        End Set
        Get
            Return prp_DigitalSignFlag
        End Get
    End Property
    Public Property CertificatePass As String
        Set(value As String)
            prp_CertificatePass = value
        End Set
        Get
            Return prp_CertificatePass
        End Get
    End Property
    Public Property CertificatePath As String
        Set(value As String)
            prp_CertificatePath = value
        End Set
        Get
            Return prp_CertificatePath
        End Get
    End Property
    Public Property ImageSignPath As String
        Set(value As String)
            prp_ImageSignPath = value
        End Set
        Get
            Return prp_ImageSignPath
        End Get
    End Property

    Public Property GSBServerPath As String
        Set(value As String)
            prp_GSBServerPath = value
        End Set
        Get
            Return prp_GSBServerPath
        End Get
    End Property
    Public Property PDFFixForm As String
        Set(value As String)
            prp_PDFFixForm = value
        End Set
        Get
            Return prp_PDFFixForm
        End Get
    End Property

    Public Property PDFFolder As String
        Set(value As String)
            prp_PDFFolder = value
        End Set
        Get
            Return prp_PDFFolder
        End Get
    End Property
    Public Property AppNo As String
        Set(value As String)
            prp_AppNo = value
        End Set
        Get
            Return prp_AppNo
        End Get
    End Property
    Public Property TemplateName As String
        Set(value As String)
            prp_TemplateName = value
        End Set
        Get
            Return prp_TemplateName
        End Get
    End Property

    Public Property RequestID As String
        Set(value As String)
            prp_RequestID = value
        End Set
        Get
            Return prp_RequestID
        End Get
    End Property
   
End Module

