﻿Imports System.IO
Imports System.Web.Services.Protocols
Imports System
Public Class clsSamplePDF
    Private Ssql As String = ""
    Private mdtAgent As DataTable
    Private msgTitle As String
    Private msgDesc As String

    Private rsExec As New ReportExecution2005.ReportExecutionService()
    Public Function StartProcess() As Boolean


        ProcessAQIS_CurrentQuarter()

        Return True
    End Function
    Private Sub ProcessAQIS_CurrentQuarter()
        Dim strAgtGrpCode As String
        Dim strAgtActualCode As String
        Dim strType As String
        Dim bResult As Boolean = True


        Dim str_report_path As String = ""
        Dim str_report_folder As String = ""
        Dim str_report_name As String = ""
        Dim str_Pdf_filename As String = ""

        '//Create a new proxy to the web service
        Dim v_report_server As String = modMain.ReportServer

        '// Authenticate to the Web service using Windows credentials
        rsExec.Credentials = System.Net.CredentialCache.DefaultCredentials
        '// Assign the URL of the Web service

        rsExec.Url = v_report_server & "/reportexecution2005.asmx?wsdl"

        Ssql = "SELECT AGT_AgentProcessedList.AgentCode, AGT_AgentProcessedList.ProcessedDate, AGT_AgentProcessedList.Type, AGT_AgentGroup.AgentCode AS ActualAgentCode " & _
            "FROM AGT_AgentProcessedList INNER JOIN AGT_AgentGroup ON AGT_AgentProcessedList.AgentCode = AGT_AgentGroup.AgentGroupCode " & _
            "ORDER BY AGT_AgentProcessedList.AgentCode"

        If Not KDB.OpenRs(mdtAgent, Ssql, "AGT_AgentProcessedList") Then
            If Not KDB.GetLastException Is Nothing Then
                logWriter.WriteLine("")
                WriteLogFile("ProcessAQIS_CurrentQuarter", "Error in calling ProcessAgentList", KDB.GetLastException.Message.ToString)
                logWriter.WriteLine("")
            End If
        End If

        If mdtAgent Is Nothing Then Exit Sub

        If mdtAgent.Rows.Count > 0 Then

            logWriter.WriteLine("")
            logWriter.WriteLine(vbTab & vbTab & "Total records found : " + mdtAgent.Rows.Count.ToString)
            logWriter.WriteLine("")
            For Each row As DataRow In mdtAgent.Rows

                If Not bResult Then Exit For
                strAgtGrpCode = ""
                strAgtActualCode = ""
                strType = ""

                strAgtGrpCode = "" & row.Item("Code")
                strAgtActualCode = "" & row.Item("ActualCode")
                strType = "" & row.Item("Type")

                str_report_path = ""
                str_report_folder = ""
                str_report_name = ""
                str_Pdf_filename = ""
                Select Case strType.ToUpper

                    Case "1", "2"
                        str_report_folder = "ReportFolder"
                        str_report_name = "TierAgent"
                    Case "3"
                        str_report_folder = "ReportFolder"
                        str_report_name = "UntierAgent"
                    Case Else
                End Select

                If str_report_folder <> "" And str_report_name <> "" Then
                    str_report_path = "/" & str_report_folder & "/" & str_report_name
                    str_Pdf_filename = "\\ipaddress\pathfolder\" & strAgtActualCode & ".pdf"


                    bResult = Create_AQIS_CurrentQuarter_PDF_V2(str_report_path, str_Pdf_filename, strAgtGrpCode, strAgtActualCode, strType)
                End If


            Next row

        End If

        If Not mdtAgent Is Nothing Then mdtAgent.Dispose()
        mdtAgent = Nothing

        If Not rsExec Is Nothing Then rsExec.Dispose()
        rsExec = Nothing

    End Sub
    Private Sub GetReportParameter(ByVal v_report_path As String)
        Dim str_report_server As String = modMain.ReportServer

        Dim rs As New ReportService2005.ReportingService2005()
        rs.Credentials = System.Net.CredentialCache.DefaultCredentials

        '// Assign the URL of the Web service
        rs.Url = str_report_server & "/reportservice2005.asmx?wsdl"


        '// Define variables needed for GetParameters() method
        '// Get the report name

        Dim _reportName As String = v_report_path
        Dim _historyid As String = Nothing
        Dim _forRendering As Boolean = False
        Dim _values As ReportService2005.ParameterValue() = Nothing
        Dim _credentials As ReportService2005.DataSourceCredentials() = Nothing
        Dim _parameters As ReportService2005.ReportParameter() = Nothing


        Try
            _parameters = rs.GetReportParameters(_reportName, _historyid, _forRendering, _values, _credentials)

            '//debug report parameter
            If Not (_parameters Is Nothing) Then
                Dim rp As ReportService2005.ReportParameter
                For Each rp In _parameters
                    Console.WriteLine("Name: {0}", rp.Name)
                Next rp
            End If


        Catch e As SoapException
            Console.WriteLine(e.Detail.InnerXml.ToString())
        End Try



    End Sub


    Private Function Create_AQIS_CurrentQuarter_PDF(ByVal v_report_path As String, _
                                            ByVal v_Pdf_filename As String,
                                            ByVal v_AgentGrpCode As String, _
                                            ByVal v_AgentActualCode As String, _
                                            ByVal v_Type As String) As Boolean

        Create_AQIS_CurrentQuarter_PDF = True


        '//Create a new proxy to the web service
        Dim v_report_server As String = modMain.ReportServer


        Dim rs As New ReportService2005.ReportingService2005()
        Dim rsExec As New ReportExecution2005.ReportExecutionService()

        '// Authenticate to the Web service using Windows credentials

        rs.Credentials = System.Net.CredentialCache.DefaultCredentials
        rsExec.Credentials = System.Net.CredentialCache.DefaultCredentials
        '// Assign the URL of the Web service
        rs.Url = v_report_server & "/reportservice2005.asmx?wsdl"
        rsExec.Url = v_report_server & "/reportexecution2005.asmx?wsdl"

        '// Prepare Render arguments
        Dim results() As Byte = Nothing
        Dim historyid As String = Nothing
        Dim format As String = "EXCEL"
        Dim devinfo As String = "<DeviceInfo><Toolbar>False</Toolbar></DeviceInfo>"


        '// Default Path;
        Dim Filename As String = v_Pdf_filename

        '// Define variables needed for GetParameters() method
        '// Get the report name

        Dim _reportName As String = v_report_path
        Dim _historyid As String = Nothing
        Dim _forRendering As Boolean = False
        Dim _values As ReportService2005.ParameterValue() = Nothing
        Dim _credentials As ReportService2005.DataSourceCredentials() = Nothing
        Dim _parameters As ReportService2005.ReportParameter() = Nothing




        Try
            '// Get if any parameters needed.
            _parameters = rs.GetReportParameters(_reportName, _historyid, _forRendering, _values, _credentials)

            '// Load the selected report.
            Dim credentials As ReportExecution2005.DataSourceCredentials() = Nothing
            Dim showHideToggle As String = Nothing
            Dim encoding As String = ""
            Dim mimetype As String = ""
            Dim warnings As ReportExecution2005.Warning() = Nothing
            Dim reportHistoryParameters As ReportExecution2005.ParameterValue() = Nothing
            Dim streamid As String() = Nothing

            Dim execInfo As New ReportExecution2005.ExecutionInfo
            Dim execHeader As New ReportExecution2005.ExecutionHeader()
            Dim SessionId As String
            Dim extension As String = ""

            rsExec.ExecutionHeaderValue = execHeader
            execInfo = rsExec.LoadReport(_reportName, historyid)

            '// Set the parameters for the report needed.
            Dim parameters(2) As ReportExecution2005.ParameterValue 'hardcode no. of parameter

            '// Place to include the parameter.
            If (_parameters.Length > 0) Then

                parameters(0) = New ReportExecution2005.ParameterValue()
                parameters(0).Name = "pAgentGroupCode"
                parameters(0).Value = v_AgentGrpCode

                parameters(1) = New ReportExecution2005.ParameterValue()
                parameters(1).Name = "pAgentCode"
                parameters(1).Value = v_AgentActualCode

                parameters(2) = New ReportExecution2005.ParameterValue()
                parameters(2).Name = "pType"
                parameters(2).Value = v_Type

            End If
            rsExec.SetExecutionParameters(parameters, "en-us")

            SessionId = rsExec.ExecutionHeaderValue.ExecutionID
            Console.WriteLine("SessionID: {0}", rsExec.ExecutionHeaderValue.ExecutionID)

            Try
                results = rsExec.Render(format, devinfo, extension, encoding, mimetype, warnings, streamid)

                execInfo = rsExec.GetExecutionInfo()
                Console.WriteLine("Execution date and time: {0}", execInfo.ExecutionDateTime)
            Catch e As SoapException
                Console.WriteLine(e.Detail.OuterXml)
                Create_AQIS_CurrentQuarter_PDF = False
            End Try


            '// Create a file stream and write the report to it

            Dim stream As FileStream = File.Create(Filename, results.Length)
            stream.Write(results, 0, results.Length)
            stream.Close()
            stream = Nothing




        Catch ex As Exception
            logWriter.WriteLine("")
            logWriter.WriteLine(vbTab & vbTab & "Error calling Create__PDF" & ex.ToString)
            logWriter.WriteLine("")

            Create_AQIS_CurrentQuarter_PDF = False
        End Try

    End Function

    Private Function Create_AQIS_CurrentQuarter_PDF_V2(ByVal v_report_path As String, _
                                            ByVal v_Pdf_filename As String,
                                            ByVal v_AgentGrpCode As String, _
                                            ByVal v_AgentActualCode As String, _
                                            ByVal v_Type As String) As Boolean

        Create_AQIS_CurrentQuarter_PDF_V2 = True


        '// Prepare Render arguments
        Dim results() As Byte = Nothing
        Dim historyid As String = Nothing
        Dim format As String = "EXCEL"
        Dim devinfo As String = "<DeviceInfo><Toolbar>False</Toolbar></DeviceInfo>"


        '// Default Path;
        Dim Filename As String = v_Pdf_filename

        '// Get the report name

        Dim _reportName As String = v_report_path

        Try

            '// Load the selected report.
            Dim credentials As ReportExecution2005.DataSourceCredentials() = Nothing
            Dim showHideToggle As String = Nothing
            Dim encoding As String = ""
            Dim mimetype As String = ""
            Dim warnings As ReportExecution2005.Warning() = Nothing
            Dim reportHistoryParameters As ReportExecution2005.ParameterValue() = Nothing
            Dim streamid As String() = Nothing

            Dim execInfo As New ReportExecution2005.ExecutionInfo
            Dim execHeader As New ReportExecution2005.ExecutionHeader()
            Dim SessionId As String
            Dim extension As String = ""

            rsExec.ExecutionHeaderValue = execHeader
            execInfo = rsExec.LoadReport(_reportName, historyid)


            '// Prepare report parameter
            '// Set the parameters for the report needed.
            Dim parameters(2) As ReportExecution2005.ParameterValue 'hardcode no. of parameter



            parameters(0) = New ReportExecution2005.ParameterValue()
            parameters(0).Name = "pAgentGroupCode"
            parameters(0).Value = v_AgentGrpCode

            parameters(1) = New ReportExecution2005.ParameterValue()
            parameters(1).Name = "pAgentCode"
            parameters(1).Value = v_AgentActualCode

            parameters(2) = New ReportExecution2005.ParameterValue()
            parameters(2).Name = "pType"
            parameters(2).Value = v_Type

            rsExec.SetExecutionParameters(parameters, "en-us")

            SessionId = rsExec.ExecutionHeaderValue.ExecutionID
            Console.WriteLine("SessionID: {0}", rsExec.ExecutionHeaderValue.ExecutionID)

            Try
                results = rsExec.Render(format, devinfo, extension, encoding, mimetype, warnings, streamid)

                execInfo = rsExec.GetExecutionInfo()
                Console.WriteLine("Execution date and time: {0}", execInfo.ExecutionDateTime)
            Catch e As SoapException
                Console.WriteLine(e.Detail.OuterXml)
                Create_AQIS_CurrentQuarter_PDF_V2 = False
            End Try


            '// Create a file stream and write the report to it

            Dim stream As FileStream = File.Create(Filename, results.Length)
            stream.Write(results, 0, results.Length)
            stream.Close()
            stream = Nothing



        Catch ex As Exception
            logWriter.WriteLine("")
            logWriter.WriteLine(vbTab & vbTab & "Error calling Create_PDF_V2" & ex.ToString)
            logWriter.WriteLine("")

            Create_AQIS_CurrentQuarter_PDF_V2 = False
        End Try


    End Function


End Class
