﻿Imports System.ComponentModel
Imports System.IO
Imports System
Imports System.Messaging
Imports System.Text
Imports System.Xml

Imports System.Security.Cryptography.X509Certificates


Imports iTextSharp.text.pdf
Imports iTextSharp.text.pdf.security
Imports iTextSharp.text.pdf.BarcodeQRCode
Imports iTextSharp.text

Public Class frmMain

    Private bw As New BackgroundWorker

    Private qMain As MessageQueue
    Private msgMain As Message
    Private mqTran As New MessageQueueTransaction()

    Private mstrPrevLog As String

    Private sqlconn As SqlClient.SqlConnection



    Private Sub frmMain_Load(sender As Object, e As EventArgs) Handles Me.Load

        'debug
        'SendMessageTransQueue()


        bw.WorkerReportsProgress = True
        bw.WorkerSupportsCancellation = True
        AddHandler bw.DoWork, New DoWorkEventHandler(AddressOf bw_DoWork)
        AddHandler bw.ProgressChanged, New ProgressChangedEventHandler(AddressOf bw_ProgressChanged)
        AddHandler bw.RunWorkerCompleted, New RunWorkerCompletedEventHandler(AddressOf bw_RunWorkerCompleted)

        InitLogFile()
        'listen and read message queue
        InitQ()


        Dim oe As System.EventArgs
        cmdStart_Click(cmdStart, oe)

       
    End Sub
    Private Sub bw_DoWork(ByVal sender As Object, ByVal e As DoWorkEventArgs)
        Dim worker As BackgroundWorker = CType(sender, BackgroundWorker)

        Dim blnHasMsg As Boolean
        Dim strId As String = ""
        Dim strMsgLabel As String
        Dim strMsgBody As String
        Dim strThaiLIFEClient As String

        Dim TempStr As String = ""
        Dim strUpdateSQL As String
        Dim strProgId As String
        Dim strPdfFilename As String
        Dim strPdfOutput As String
        Dim strPdfFixForm As String
        Dim strGSBServerPath As String
        Dim strPDFFolder As String

        Dim strImageSignPath As String
        Dim strCertificatePath As String
        Dim strDigitalSignPass As String
        Dim strDigitalSignFlag As String
        Dim strServerPath_SubFolder As String
        Dim strServerPath_SubFolderByJobId As String
        Dim strSplitBySubClassFolderFlag As String
        Dim strSplitSubClassDestination As String


        While True
            System.Windows.Forms.Application.DoEvents()


            'Close Existing log file and create another new log file if the current date is changed
            If DateTime.Now.ToString("yyyyMMdd", New System.Globalization.CultureInfo("en-US")) <> mstrPrevLog Then

                logWriter.WriteLine("")
                logWriter.WriteLine(vbTab & "Generating PDF Report End: " + DateTime.Now.ToString("dd-MM-yyyy h:mm:ss tt", New System.Globalization.CultureInfo("en-US")))
                logWriter.WriteLine("")
                logWriter.Close()

                InitLogFile()
              
            End If

            blnHasMsg = True

            Try
                mqTran = New MessageQueueTransaction()
                mqTran.Begin()
                msgMain = qMain.Receive(New TimeSpan(0, 0, 1), mqTran)
                mqTran.Commit()
            Catch qex As System.Messaging.MessageQueueException
                If qex.MessageQueueErrorCode <> MessageQueueErrorCode.IOTimeout Then
                    WriteLogFile("bw_DoWork", "Error in receiving message from MSMQ", qex.Message.ToString)
                End If
                If mqTran.Status = MessageQueueTransactionStatus.Pending Then mqTran.Abort()

                blnHasMsg = False

            End Try

            If blnHasMsg Then
                'CheckDBConnection()

                logWriter.WriteLine("")
                logWriter.WriteLine(vbTab & vbTab & "Receiving a message from MSMQ: " + DateTime.Now.ToString("dd-MM-yyyy h:mm:ss tt", New System.Globalization.CultureInfo("en-US")))
                logWriter.WriteLine("")

                Try
                    msgMain.Formatter = New XmlMessageFormatter(New [String]() {"System.String,mscorlib"})
                Catch ex As Exception
                    WriteLogFile("bw_DoWork", "Error in formatting msmq message", ex.Message.ToString)
                End Try

                strId = msgMain.Id.ToString
                strMsgLabel = msgMain.Label.ToString
                modMain.ProgramId = strMsgLabel.Trim
                strMsgBody = msgMain.Body.ToString


                'SQL db
                strThaiLIFEClient = ""

                KDB.GetResValue("ThaiLIFE", modMain.ProgramId, strThaiLIFEClient)

                modMain.Client = strThaiLIFEClient.Trim
                If Not KDB.MakeConnection(strThaiLIFEClient.Trim) Then
                    WriteLogFile("Connection confirmation", "Error on connecting to SQL database", "")
                    If KDB.GetLastErrorCode <> 0 Then

                        MessageBox.Show(KDB.GetLastException.Message, "Thai_PDFReport")



                        If bw.CancellationPending = True Then
                            e.Cancel = True
                            Exit While
                        End If
                    End If
                End If
                'Init SQL connection
                InitConnection()



                strPdfOutput = ""
                KDB.GetResValue(strThaiLIFEClient.Trim, "PDFOutput", strPdfOutput)
                strPdfOutput = strPdfOutput.Trim
                If Not strPdfOutput.EndsWith("\") Then
                    strPdfOutput &= "\"
                End If
                modMain.PDFOutput = strPdfOutput.Trim


                strPdfFixForm = ""
                KDB.GetResValue(strThaiLIFEClient.Trim, "PDFFixForm", strPdfFixForm)
                strPdfFixForm = strPdfFixForm.Trim
                If Not strPdfFixForm.EndsWith("\") Then
                    strPdfFixForm &= "\"
                End If
                modMain.PDFFixForm = strPdfFixForm.Trim

                'Get GSBServerPath directory
                strGSBServerPath = ""
                KDB.GetResValue(strThaiLIFEClient.Trim, "GSBServerPath", strGSBServerPath)
                strGSBServerPath = strGSBServerPath.Trim
                If Not strGSBServerPath.EndsWith("\") Then
                    strGSBServerPath &= "\"
                End If
                modMain.GSBServerPath = strGSBServerPath.Trim



                'Get PDFFolder directory
                strPDFFolder = ""
                KDB.GetResValue(strThaiLIFEClient.Trim, "PDFFolder", strPDFFolder)
                strPDFFolder = strPDFFolder.Trim
                modMain.PDFFolder = strPDFFolder.Trim



                strImageSignPath = ""
                KDB.GetResValue(strThaiLIFEClient.Trim, "ImageSignPath", strImageSignPath)
                strImageSignPath = strImageSignPath.Trim
                modMain.ImageSignPath = strImageSignPath

                strCertificatePath = ""
                KDB.GetResValue(strThaiLIFEClient.Trim, "CertificatePath", strCertificatePath)
                strCertificatePath = strCertificatePath.Trim
                modMain.CertificatePath = strCertificatePath

                strDigitalSignPass = ""
                KDB.GetResValue(strThaiLIFEClient.Trim, "CertificatePass", strDigitalSignPass)
                strDigitalSignPass = strDigitalSignPass.Trim
                modMain.CertificatePass = strDigitalSignPass

                strDigitalSignFlag = ""
                KDB.GetResValue(strThaiLIFEClient.Trim, "DigitalSignFlag", strDigitalSignFlag)
                strDigitalSignFlag = strDigitalSignFlag.Trim
                modMain.DigitalSignFlag = strDigitalSignFlag

                strServerPath_SubFolder = ""
                KDB.GetResValue(strThaiLIFEClient.Trim, "GSBServerPath_SubFolder_Year", strServerPath_SubFolder)
                strServerPath_SubFolder = strServerPath_SubFolder.Trim
                modMain.ServerPath_SubFolder = strServerPath_SubFolder

                strServerPath_SubFolderByJobId = ""
                KDB.GetResValue(strThaiLIFEClient.Trim, "GSBServerPath_SubFolder_ByJobId", strServerPath_SubFolderByJobId)
                strServerPath_SubFolderByJobId = strServerPath_SubFolderByJobId.Trim
                modMain.ServerPath_SubFolderByJobId = strServerPath_SubFolderByJobId


                strSplitBySubClassFolderFlag = ""
                KDB.GetResValue(strThaiLIFEClient.Trim, "SplitBySubClassFolder", strSplitBySubClassFolderFlag)
                strSplitBySubClassFolderFlag = strSplitBySubClassFolderFlag.Trim
                modMain.SplitBySubClassFolderFlag = strSplitBySubClassFolderFlag




                strMsgBody = strMsgBody.Replace("'amp'", "&")


                Select Case strThaiLIFEClient.Trim
                    Case "EVC"
                        SplitData_EVC(strMsgBody)
                    Case "OPER"
                        SplitData_Oper(strMsgBody)
                    Case Else
                        SplitDataV2(strMsgBody)
                        ''SplitData(strMsgBody)
                End Select



            End If


            If bw.CancellationPending = True Then
                e.Cancel = True
                Exit While
            End If

        End While
       
    End Sub
    Private Sub bw_RunWorkerCompleted(ByVal sender As Object, ByVal e As RunWorkerCompletedEventArgs)

    End Sub
    Private Sub bw_ProgressChanged(ByVal sender As Object, ByVal e As ProgressChangedEventArgs)

    End Sub

       
    Private Sub frmMain_FormClosing(sender As Object, e As FormClosingEventArgs) Handles Me.FormClosing

        'CloseQueueListening
        cmdStop_Click(sender, e)


        If sqlconn IsNot Nothing Then
            sqlconn.Close()
            sqlconn.Dispose()
        End If

        sqlconn = Nothing

        logWriter.WriteLine("")
        logWriter.WriteLine(vbTab & "Generating PDF Report End: " + DateTime.Now.ToString("dd-MM-yyyy h:mm:ss tt", New System.Globalization.CultureInfo("en-US")))
        logWriter.WriteLine("")
        logWriter.Close()


    End Sub

    Private Sub InitLogFile()
        Dim AppPath As String = System.AppDomain.CurrentDomain.BaseDirectory.Trim
        Dim LogDir As String = ""
        Dim logFile As String = ""
        Dim logFileExist As Boolean

        LogDir = System.IO.Path.Combine(AppPath, DateTime.Now.ToString("yyyy", New System.Globalization.CultureInfo("en-US")))
        LogDir = System.IO.Path.Combine(LogDir, DateTime.Now.ToString("MM", New System.Globalization.CultureInfo("en-US")))
        If Not System.IO.Directory.Exists(LogDir) Then
            System.IO.Directory.CreateDirectory(LogDir)
        End If

        logFile = System.IO.Path.Combine(LogDir, "PDFReport_" & DateTime.Now.ToString("yyyyMMdd", New System.Globalization.CultureInfo("en-US")) & ".log")

        mstrPrevLog = DateTime.Now.ToString("yyyyMMdd", New System.Globalization.CultureInfo("en-US"))

        logFileExist = System.IO.File.Exists(logFile)
        logWriter = New System.IO.StreamWriter(logFile, True)
        logWriter.AutoFlush = True

        If logFileExist Then
            logWriter.WriteLine("")
            logWriter.WriteLine(Microsoft.VisualBasic.StrDup(80, "~"))
            logWriter.WriteLine("")
        End If

        logWriter.WriteLine("Generating PDF Report Auto Log")
        logWriter.WriteLine("------------------------------")
        logWriter.WriteLine("")
        logWriter.WriteLine(vbTab & "Generating PDF Report Start : " + DateTime.Now.ToString("dd-MM-yyyy h:mm:ss tt", New System.Globalization.CultureInfo("en-US")))
        logWriter.WriteLine("")

    End Sub

    Private Sub InitConnection()
        Dim strConn As String = ""
        Me.sqlconn = modMain.KDB.GetDBConnection
    End Sub

    Private Sub cmdStart_Click(sender As Object, e As EventArgs) Handles cmdStart.Click
        cmdStart.Enabled = False
        If Not bw.IsBusy = True Then
            bw.RunWorkerAsync()

            cmdStop.Enabled = True
        End If

    End Sub

    Private Sub cmdStop_Click(sender As Object, e As EventArgs) Handles cmdStop.Click
        cmdStop.Enabled = False
        If bw.WorkerSupportsCancellation = True Then
            bw.CancelAsync()

            WriteLogFile("", "Stop listening to MSMQ", "")

            cmdStart.Enabled = True
        End If

    End Sub
    Private Sub InitQ()
        Dim strQName As String
        'Checking whether the Queue exists, if not create it.
        strQName = modMain.QPathName

        Try
            qMain = New MessageQueue(strQName)

        Catch ex As Exception
            MessageBox.Show("Error in initializing MSMQ - " & ex.Message.ToString)
            WriteLogFile("", "Error in initializing MSMQ", ex.Message.ToString)
            GoTo ExitSub
        End Try

        logWriter.WriteLine("")
        logWriter.WriteLine(vbTab & "Initializing MSMQ Start : " + DateTime.Now.ToString("dd-MM-yyyy h:mm:ss tt", New System.Globalization.CultureInfo("en-US")))
        logWriter.WriteLine("")
ExitSub:

    End Sub

    Private Sub ReadMessageQueue()
        'Note: When we send a message to the MSMQ queue using System.Messaging class, the message body is surrounded by a <String> Wrapper and <?xml version="1.0"?>
        'Use XMLMessageFormatter to receive the message without the string wrapper.
        Dim m As New System.Messaging.Message()
        Dim msgQ As New MessageQueue(".\private$\Testpgm")
        m = msgQ.Receive() 'Use receive() function to receive the message: 
        m.Formatter = New XmlMessageFormatter(New [String]() {"System.String,mscorlib"})
        Dim text As String = m.Body.ToString()
        Dim xml As New XmlDocument()
        xml.LoadXml(text)
        xml.Save("c:\temp\myxml.xml") 'Save the message to the file location to test:
    End Sub

    Private Sub SendMessageQueue()

        Try
            Dim xd As New XmlDocument()
            xd.Load("c:\temp\myxml.xml")
            Dim msg As New System.Messaging.Message()
            msg.Label = "TestMessage"
            msg.Body = xd.InnerXml
            msg.UseDeadLetterQueue = True
            Dim msgQ As New MessageQueue("ipaddress\private$\Folder")
            msgQ.Send(msg)
        Catch ex As Exception
            MessageBox.Show(ex.Message)
        End Try
       
    End Sub

    Private Sub SendMessageTransQueue()

        Dim xd As New XmlDocument()
        'xd.Load("c:\temp\myxml.xml")

        xd.LoadXml("<parameters>" &
                    "<ProgId>abc123</ProgId>" &
                    "<PdfFilename>\\ipaddress\Share\PDF\Testing.pdf</PdfFilename>" &
                    "</parameters>")

        Dim msg As New System.Messaging.Message()
        msg.Label = "Insurer1"
        msg.Body = xd.InnerXml
        msg.UseDeadLetterQueue = True


        Dim qTrn As New MessageQueueTransaction
        qTrn.Begin()
        Try
            Dim msgQ As New MessageQueue("ipaddress\private$\pdf folder")
            msgQ.Send(msg, qTrn) 'Use send() function to send the message 
            qTrn.Commit()
        Catch ex As Exception
            qTrn.Abort()
            MessageBox.Show(ex.Message)
        End Try

        If qTrn IsNot Nothing Then qTrn.Dispose()
        If msg IsNot Nothing Then msg.Dispose()

        qTrn = Nothing
        msg = Nothing

    End Sub

    Private Sub SplitData(ByVal v_MsgBody As String)


        If v_MsgBody.Contains(Chr(252)) Then

            Call BatchPrintingSign(v_MsgBody)

            Exit Sub
        End If


       
        Dim sAppNo As String = ""
        Dim sPdfId As String = ""
        Dim sql As String = ""
        Dim sqlInsert As String = ""
        Dim sqlTableName As String
        Dim sqlFieldName As String
        Dim sqlFieldValue As String

        Dim FieldName, FieldValue As String
        Dim lFields As List(Of String)

        Dim bResult As Boolean
        Dim TemplateList As String = ""
        Dim tempPdffilename As String = ""


        Dim sRequestId As String
        sRequestId = GetGUID()

        Dim Template As Array = Split(v_MsgBody, Chr(255))

        If Template.Length < 1 Then
            WriteLogFile("Split Data", "Template Delimiter CHR(255) NOT Found ...", "")
            Exit Sub
        End If



        For a As Integer = 0 To Template.Length - 1

            If a = 0 Then


                Dim sKey As Array = Split(Template(a).ToString, Chr(254))
                If sKey.Length < 1 Then
                    WriteLogFile("", "Field Delimiter CHR(254) NOT Found ...", "")
                    WriteLogFile("", "Error in SplitData.  Cannot get Appno and pdfid", "")
                    Exit Sub
                End If

                Dim sKey2 As Array = Split(sKey(2).ToString, Chr(253)) 'sKey(2) store appno, pdfid
                If sKey2.Length < 1 Then
                    WriteLogFile("", "Value Delimiter CHR(253) NOT Found ...", "")
                    WriteLogFile("", "Error in SplitData. Cannot get Appno and pdfid", "")
                    Exit Sub
                End If

                sAppNo = sKey2(0)
                sPdfId = sKey2(1)
                
                If sAppNo = "" Then
                    'invalid data, key not found
                    WriteLogFile("Split Data", "Error in SplitData. Key not found", "")
                    Exit For
                End If
                modMain.AppNo = ""
                modMain.AppNo = sAppNo

                'original pdffilename
                modMain.PDFFilename = ""
                modMain.PDFFilename = modMain.PDFOutput & sPdfId


                tempPdffilename = modMain.PDFOutput & sRequestId & "tmp" & sPdfId

            Else
                sqlFieldName = ""
                sqlFieldValue = ""
                Dim sField As Array = Split(Template(a), Chr(254))

                If sField.Length < 1 Then
                    WriteLogFile("", "Field Delimiter CHR(254) NOT Found...", "")
                    WriteLogFile("", "Error in SplitData. Cannot get Template Name. Continue for Next Template", "")
                    Continue For
                End If

                'get template name/table name sField(0)
                Dim sValue As Array = Split(sField(0), Chr(253))    ' for each field value in template
                If sValue.Length < 1 Then
                    WriteLogFile("", "Field Delimiter CHR(253) NOT Found...", "")
                    WriteLogFile("", "Error in SplitData. Cannot get Template Name. Continue for Next Template", "")
                    Continue For
                End If

                sqlTableName = sValue(0)
                modMain.TemplateName = ""
                modMain.TemplateName = sqlTableName
                modMain.RequestID = sRequestId


                If TemplateList <> "" Then



                    TemplateList = TemplateList & " " & modMain.PDFOutput & modMain.AppNo & "_" & modMain.TemplateName & "_" & modMain.RequestID & ".pdf"
                Else


                    TemplateList = modMain.PDFOutput & modMain.AppNo & "_" & modMain.TemplateName & "_" & modMain.RequestID & ".pdf"
                End If


                Dim sourcePath As String = ""
                If Not sqlTableName.Contains("_") Then GoTo Cont

                Dim FixFormName As Array = Split(sqlTableName.ToUpper, "_")

                If CheckPDFFixForm(modMain.Client, FixFormName(0), sourcePath) Then

                    Dim sourceFilename As String = ""
                    Dim destFilename As String = ""


                    sourcePath = sourcePath.Trim
                    If Not sourcePath.EndsWith("\") Then
                        sourcePath &= "\"
                    End If

                    sourceFilename = sourcePath & sqlTableName & ".pdf"
                    destFilename = modMain.PDFOutput & modMain.AppNo & "_" & modMain.TemplateName & "_" & modMain.RequestID & ".pdf"

                    'check file exist
                    If System.IO.File.Exists(sourceFilename) = True Then

                        Try

                            My.Computer.FileSystem.CopyFile(sourceFilename, destFilename, True)
                        Catch ex As Exception
                            WriteLogFile("CopyFile", "Error on Copy file -- " & ex.Message, "")
                        End Try

                    Else
                        WriteLogFile("CopyFile", "Error in copy file. " & sourceFilename & " does not exist.", "")
                    End If
                    Continue For
                End If

Cont:
                Dim dt As System.Data.DataTable
                Dim dc As System.Data.DataColumn
                dt = Nothing


                Dim fieldValues As String

                fieldValues = ""

                sql = "select * from [" & sqlTableName & "] where [PK_TBL] = '" & sAppNo & "'; "
                If Not KDB.OpenRs(dt, sql, "Tbl") Then Continue For



                lFields = New List(Of String)

                For x As Integer = 1 To sField.Length - 1 'start at sField(1) because sField(0) is templatename/tablename
                    Erase sValue
                    sValue = Split(sField(x), Chr(253))

                    FieldName = sValue(0)
                    FieldValue = sValue(1)


                    If Not dt.Columns.Contains(FieldName) Then Continue For

                    If lFields.Contains(FieldName) Then Continue For

                    lFields.Add(FieldName)
                    Select Case dt.Columns(FieldName).DataType.Name
                        Case "System.String", "String"
                            FieldValue = "N'" & FieldValue.Replace("'", "''") & "'"

                        Case "Boolean"
                            If sValue(1) = "True" Then
                                FieldValue = "1"
                            Else
                                FieldValue = "0"
                            End If

                        Case "DateTime"
                            FieldValue = "'" & CType(dt.Rows(0)(dc.ColumnName), DateTime).ToString("yyyy-MM-dd HH:mm:ss", System.Globalization.CultureInfo.InvariantCulture) & "'"

                        Case "Currency", "Decimal"
                            FieldValue = FieldValue.Replace(",", "")

                        Case Else
                    End Select

                    If sqlFieldName <> "" Then sqlFieldName &= ", "
                    sqlFieldName &= "[" & FieldName & "]"

                    If sqlFieldValue <> "" Then sqlFieldValue &= ", "
                    sqlFieldValue &= FieldValue
                Next

                lFields.Clear()
                lFields = Nothing

                sql = ""
                If dt.Rows.Count > 0 Then
                    ' delete record
                    sql = "DELETE FROM [" & sqlTableName & "] where [PK_TBL] = '" & sAppNo & "' ; "
                End If

                ' insert record
                sqlInsert = ""
                sqlInsert = sql & "INSERT INTO [" & sqlTableName & "] ( [PK_TBL] ," & sqlFieldName & ") " & vbCrLf & _
                            "VALUES ( '" & sAppNo & "', " & sqlFieldValue & ") ; "


                bResult = UpdateDatabase(sqlInsert)

                If bResult Then
                    'print pdf
                    Dim objProcessThaiLife As New clsThaiLife
                    objProcessThaiLife = New clsThaiLife
                    objProcessThaiLife.StartProcess()
                    objProcessThaiLife = Nothing

                End If
            End If
        Next



        Dim pdf As System.Diagnostics.Process
        pdf = New System.Diagnostics.Process

        Dim tempfilePath As String = ""
        Dim orifilePath As String = ""
        Dim ServerPath As String = ""

        Try
            Try
                pdf.StartInfo.UseShellExecute = True
                'pdf.StartInfo.FileName = "C:\Program Files (x86)\PDFtk\bin\pdftk.exe"
                pdf.StartInfo.FileName = "C:\Program Files\PDFtk\bin\pdftk.exe"
                'pdf.StartInfo.Arguments = TemplateList & " cat output " & modMain.PDFFilename
                pdf.StartInfo.Arguments = TemplateList & " cat output " & tempPdffilename '  modMain.PDFFilename
                pdf.StartInfo.WindowStyle = ProcessWindowStyle.Minimized
                pdf.Start()


                pdf.WaitForExit()


            Catch expdf As Exception
                WriteLogFile("Shell PDFtk", "Error in starting process PDFtk", expdf.Message.ToString)
                'pdf.Kill()
            End Try
            pdf.Dispose()
            pdf = Nothing


            'rename to ori pdf name

            tempfilePath = tempPdffilename

            orifilePath = sPdfId ' modMain.PDFFilename
            If File.Exists(tempfilePath) Then


                If File.Exists(modMain.PDFOutput & orifilePath) Then
                    System.IO.File.Delete(modMain.PDFOutput & orifilePath)
                End If
                My.Computer.FileSystem.RenameFile(tempfilePath, orifilePath)


                If modMain.GSBServerPath <> "" Then
                    Dim destFilePath As Array = Split(modMain.GSBServerPath.ToString, ";") 'GSBServerPath store another server
                    For cnt = 0 To UBound(destFilePath)
                        ServerPath = destFilePath(cnt)

                        Dim DigitalSignFlag As String = ""
                        DigitalSignFlag = modMain.DigitalSignFlag.ToUpper
                        If DigitalSignFlag = "Y" Then
                            Call AddDigitalSign(modMain.PDFFilename, ServerPath & orifilePath, sqlTableName)
                        Else
                            My.Computer.FileSystem.CopyFile(modMain.PDFFilename, ServerPath & orifilePath, True)
                            WriteLogFile("CopyFile", "Copy File to the destination path ---- " & modMain.PDFFilename & " ---- To --- " & ServerPath & orifilePath, "")

                        End If

                        '====== End copy file
                    Next
                End If
            Else
                WriteLogFile("Rename", "Nothing to rename. No such file ---- " & tempfilePath, "")
            End If

            Dim FileToDelete As Array = Split(TemplateList, " ")
            For a = 0 To UBound(FileToDelete)
                If System.IO.File.Exists(FileToDelete(a)) = True Then
                    System.IO.File.Delete(FileToDelete(a))

                End If
            Next



        Catch ex As Exception
            WriteLogFile("Combine Multiple PDF", "Error in Combine Multiple PDF", ex.Message.ToString)
        End Try

      

    End Sub

    Private Sub AddDigitalSign(ByVal sourcePath As String, ByVal destPath As String, ByVal templatename As String)
        ''Create Digital Sign by using 'itextsharp.dll'.
        'Get file from folder
        Dim listfile As FileInfo
        Dim filename, MasterPDFPath, DestinationPDFPath As String
        Dim dir As DirectoryInfo = New DirectoryInfo(sourcePath)
        Dim strLogDetail As String

        Dim dt As DataTable
        Dim sql As String = ""
        dt = Nothing


        Try


            If File.Exists(sourcePath) Then



                Dim cert As X509Certificate2 = New X509Certificate2(modMain.CertificatePath, modMain.CertificatePass)

                'Source File
                Dim Reader As PdfReader
                PdfReader.unethicalreading = True
                Reader = New PdfReader(sourcePath)




                Dim File_stream As FileStream = New FileStream(destPath, FileMode.Create, FileAccess.ReadWrite)


                'Create digital signature
                Dim stamper As PdfStamper = PdfStamper.CreateSignature(Reader, File_stream, "\0", Nothing, True)
                Dim sap As PdfSignatureAppearance = stamper.SignatureAppearance
                Dim cp As Org.BouncyCastle.X509.X509CertificateParser = New Org.BouncyCastle.X509.X509CertificateParser()
                Dim chain As Org.BouncyCastle.X509.X509Certificate() = New Org.BouncyCastle.X509.X509Certificate() {cp.ReadCertificate(cert.RawData)}
                Dim externalSign As IExternalSignature = New X509Certificate2Signature(cert, "SHA-1")
                Dim imagepath As String
                Dim SignFileImage As iTextSharp.text.Image
                Dim arrPosition() As String
                Dim strDigitalSignReason, strDigitalSignLocation As String
                Dim strImageVisible, strDigitalVisible As Boolean
                Dim LLX, LLY, URX, URY As String




                sql = "select * from [Signature_Template_Setup] where [TemplateName] = '" & templatename & "';"

                If KDB.OpenRs(dt, sql, "Tbl") Then
                    If Not dt.Rows.Count > 0 Then
                        sql = "select * from [Signature_Template_Setup] where [TemplateName] = 'Default';"
                        dt = Nothing
                        KDB.OpenRs(dt, sql, "Tbl")
                    End If

                    strDigitalSignReason = dt.Rows(0).Item("REASON").ToString
                    strDigitalSignLocation = dt.Rows(0).Item("LOCATION").ToString
                    strImageVisible = dt.Rows(0).Item("IMAGEVISIBLE").ToString
                    strDigitalVisible = dt.Rows(0).Item("SIGNVISIBLE").ToString
                    LLX = dt.Rows(0).Item("LLX").ToString
                    LLY = dt.Rows(0).Item("LLY").ToString
                    URX = dt.Rows(0).Item("URX").ToString
                    URY = dt.Rows(0).Item("URY").ToString
                End If


                If strDigitalSignReason IsNot Nothing Or strDigitalSignReason <> "" Then
                    sap.Reason = strDigitalSignReason
                End If

                If strDigitalSignLocation IsNot Nothing Or strDigitalSignLocation <> "" Then
                    sap.Location = strDigitalSignLocation
                End If

                '========================================================================================================
                'Syntax below is image with digital sign detail
                If strImageVisible Then
                    'Image path for digital sign
                    SignFileImage = iTextSharp.text.Image.GetInstance(modMain.ImageSignPath)
                    sap.SignatureGraphic = SignFileImage
                    sap.SignatureRenderingMode = PdfSignatureAppearance.RenderingMode.GRAPHIC_AND_DESCRIPTION
                Else
                    'Syntax below is digital sign detail only.
                    sap.SignatureRenderingMode = PdfSignatureAppearance.RenderingMode.DESCRIPTION
                End If

                'Syntax below is name of digital sign only.
                'sap.SignatureRenderingMode = PdfSignatureAppearance.RenderingMode.NAME_AND_DESCRIPTION
                '========================================================================================================

                'Set visible digital signature.
                If strDigitalVisible Then
                    ' arrPosition = Split(strDigitalPosition, ",")
                    sap.SetVisibleSignature(New iTextSharp.text.Rectangle(LLX, LLY, URX, URY), 1, Nothing)
                End If

                'Create digital sign on pdf file
                MakeSignature.SignDetached(sap, externalSign, chain, Nothing, Nothing, Nothing, 0, CryptoStandard.CMS)

                strLogDetail = destPath & " is successful."
                'System.IO.File.Move(sourcePath, destPath)
                WriteLogFile("Digital Sign", "Digital Sign Successfull.", strLogDetail)


            End If

        Catch ex As Exception
            WriteLogFile("Digital Sign", "Error in Digital Signature", ex.Message.ToString)
        End Try



    End Sub

    Private Sub SplitDataV2(ByVal v_MsgBody As String)

        'checking on Batch or single Appno

        If v_MsgBody.Contains(Chr(252)) Then
            'Batch processing

            Call BatchPrintingV2(v_MsgBody)
            Exit Sub
        End If

        Dim sAppNo As String = ""
        Dim sPdfId As String = ""
        Dim sql As String = ""
        Dim sqlInsert As String = ""
        Dim sqlDelete As String = ""
        Dim sqlTableName As String
        Dim sqlTableInd As String '--M as Main Table (parent), C as child Table
        Dim sqlFieldName As String
        Dim sqlFieldValue As String

        Dim FieldName, FieldValue As String
        Dim lFields As List(Of String)

        Dim bResult As Boolean
        Dim TemplateList As String = ""
        Dim TemplateNameList As String = ""
        Dim PDFFileNameList As String = ""
        Dim tempPdffilename As String = ""

        'introduce requestid 20161214 to solve same message for multiple EXE running at the same time
        Dim sRequestId As String
        sRequestId = GetGUID()
        modMain.RequestID = sRequestId

        Dim Template As Array = Split(v_MsgBody, Chr(255))       ' for each template

        If Template.Length < 1 Then
            WriteLogFile("Split Data", "Template Delimiter CHR(255) NOT Found ...", "")
            Exit Sub
        End If


        For a As Integer = 0 To Template.Length - 1


            If a = 0 Then


                'get appno, pdfid

                Dim sKey As Array = Split(Template(a).ToString, Chr(254))
                If sKey.Length < 1 Then
                    WriteLogFile("", "Field Delimiter CHR(254) NOT Found ...", "")
                    WriteLogFile("", "Error in SplitData.  Cannot get Appno and pdfid", "")
                    Exit Sub
                End If

                Dim sKey2 As Array = Split(sKey(2).ToString, Chr(253)) 'sKey(2) store appno, pdfid
                If sKey2.Length < 1 Then
                    WriteLogFile("", "Value Delimiter CHR(253) NOT Found ...", "")
                    WriteLogFile("", "Error in SplitData. Cannot get Appno and pdfid", "")
                    Exit Sub
                End If

                sAppNo = sKey2(0)
                sPdfId = sKey2(1)


                If sAppNo = "" Then
                    'invalid data, key not found
                    WriteLogFile("Split Data", "Error in SplitData. Key not found", "")
                    Exit For
                End If



                If modMain.SplitBySubClassFolderFlag = "Y" Then
                    Dim arrAppno As String()
                    arrAppno = sAppNo.Split("_")
                    modMain.SplitSubClassDestination = arrAppno(arrAppno.Length - 1)


                End If
                '====================================================================================================

                modMain.AppNo = ""
                modMain.AppNo = sAppNo

                'original pdffilename
                modMain.PDFFilename = ""
                modMain.PDFFilename = modMain.PDFOutput & sPdfId




                tempPdffilename = modMain.PDFOutput & sRequestId & "tmp" & sPdfId

            Else
                sqlFieldName = ""
                sqlFieldValue = ""
                Dim sField As Array = Split(Template(a), Chr(254))

                If sField.Length < 1 Then
                    WriteLogFile("", "Field Delimiter CHR(254) NOT Found...", "")
                    WriteLogFile("", "Error in SplitData. Cannot get Template Name. Continue for Next Template", "")
                    Continue For
                End If

                'get template name/table name sField(0)
                Dim sValue As Array = Split(sField(0), Chr(253))    ' for each field value in template
                If sValue.Length < 1 Then
                    WriteLogFile("", "Field Delimiter CHR(253) NOT Found...", "")
                    WriteLogFile("", "Error in SplitData. Cannot get Template Name. Continue for Next Template", "")
                    Continue For
                End If

                sqlTableName = sValue(0)
                sqlTableInd = sValue(1) '--M as Main Table (parent), C as child Table


                If sqlTableInd = "M" Or sqlTableInd = "1" Then
                    If TemplateList <> "" Then

                        TemplateList = TemplateList & " " & modMain.PDFOutput & modMain.AppNo & "_" & sqlTableName & "_" & modMain.RequestID & ".pdf"
                    Else

                        TemplateList = modMain.PDFOutput & modMain.AppNo & "_" & sqlTableName & "_" & modMain.RequestID & ".pdf"
                    End If

                    'create a list to call ssrs report after data insert into sql 
                    If Not sqlTableName.Contains("_") Then
                        If TemplateNameList <> "" Then
                            TemplateNameList = TemplateNameList & " " & sqlTableName
                        Else
                            TemplateNameList = sqlTableName
                        End If

                        If PDFFileNameList <> "" Then
                            PDFFileNameList = PDFFileNameList & " " & modMain.PDFOutput & modMain.AppNo & "_" & sqlTableName & "_" & modMain.RequestID & ".pdf"
                        Else
                            PDFFileNameList = modMain.PDFOutput & modMain.AppNo & "_" & sqlTableName & "_" & modMain.RequestID & ".pdf"
                        End If
                    End If

                End If


                Dim sourcePath As String = ""
                If Not sqlTableName.Contains("_") Then GoTo Cont

                Dim FixFormName As Array = Split(sqlTableName.ToUpper, "_")

                If CheckPDFFixForm(modMain.Client, FixFormName(0), sourcePath) Then


                    Dim sourceFilename As String = ""
                    Dim destFilename As String = ""

                    'sourcePath = sField(1)
                    sourcePath = sourcePath.Trim
                    If Not sourcePath.EndsWith("\") Then
                        sourcePath &= "\"
                    End If

                    sourceFilename = sourcePath & sqlTableName & ".pdf"
                    destFilename = modMain.PDFOutput & modMain.AppNo & "_" & sqlTableName & "_" & modMain.RequestID & ".pdf"

                    'check file exist
                    If System.IO.File.Exists(sourceFilename) = True Then

                        Try

                            My.Computer.FileSystem.CopyFile(sourceFilename, destFilename, True)
                        Catch ex As Exception
                            WriteLogFile("CopyFile", "Error on Copy file -- " & ex.Message, "")
                        End Try
                    Else
                        WriteLogFile("CopyFile", "Error in copy file. " & sourceFilename & " does not exist.", "")
                    End If
                    Continue For
                End If

Cont:
                Dim dt As System.Data.DataTable
                Dim dc As System.Data.DataColumn
                dt = Nothing

                Dim fieldValues As String
                fieldValues = ""

                If sqlTableInd = "M" Or sqlTableInd = "1" Then
                    sql = "select * from [" & sqlTableName & "] where [PK_TBL] = '" & sAppNo & "'; "
                Else
                    sql = "select * from [" & sqlTableName & "]; "
                End If

                If Not KDB.OpenRs(dt, sql, "Tbl") Then Continue For



                lFields = New List(Of String)

                For x As Integer = 1 To sField.Length - 1 'start at sField(1) because sField(0) is templatename/tablename
                    Erase sValue
                    sValue = Split(sField(x), Chr(253))

                    FieldName = sValue(0)
                    FieldValue = sValue(1)

                    'if database structure do not have such field then continue next
                    If Not dt.Columns.Contains(FieldName) Then Continue For
                    'if text file contain than duplicate field name then continue next
                    If lFields.Contains(FieldName) Then Continue For

                    lFields.Add(FieldName)
                    Select Case dt.Columns(FieldName).DataType.Name
                        Case "System.String", "String"
                            FieldValue = "N'" & FieldValue.Replace("'", "''") & "'"

                        Case "Boolean"
                            If sValue(1) = "True" Then
                                FieldValue = "1"
                            Else
                                FieldValue = "0"
                            End If

                        Case "DateTime"
                            FieldValue = "'" & CType(dt.Rows(0)(dc.ColumnName), DateTime).ToString("yyyy-MM-dd HH:mm:ss", System.Globalization.CultureInfo.InvariantCulture) & "'"

                        Case "Currency", "Decimal"
                            FieldValue = FieldValue.Replace(",", "")

                        Case Else
                    End Select

                    If sqlFieldName <> "" Then sqlFieldName &= ", "
                    sqlFieldName &= "[" & FieldName & "]"

                    If sqlFieldValue <> "" Then sqlFieldValue &= ", "
                    sqlFieldValue &= FieldValue
                Next

                lFields.Clear()
                lFields = Nothing

                ' insert record

                If sqlTableInd = "M" Or sqlTableInd = "1" Then
                    sql = ""
                    If dt.Rows.Count > 0 Then
                        ' delete record
                        sql = "DELETE FROM [" & sqlTableName & "] where [PK_TBL] = '" & sAppNo & "' ; "

                        'delete the child table data as well
                        'build delete sql stmt for related table record (many side) 
                        Dim ssql As String
                        Dim dtDel As DataTable
                        Dim drDel As DataRow
                        Dim strDel As String = ""

                        dtDel = New DataTable
                        ssql = "SELECT ParentTable, ChildTable FROM [DEL_DEPENDENCIES] WHERE ParentTable = '" & sqlTableName & "'"
                        If KDB.OpenRs(dtDel, ssql, "DelTable") Then
                            For Each drDel In dtDel.Rows
                                strDel = ""
                                strDel = drDel.Item("ChildTable").ToString
                                'remarks: key of child table for EVC not PK_TBL, is autokey 
                                sqlDelete = sqlDelete & "DELETE FROM [" & strDel & "] where [REF_KEY] = '" & sAppNo & "' ; "
                            Next
                        Else
                            WriteLogFile("SQL Insert", "Error during select ---- " & ssql, "")
                        End If
                    End If

                    sqlInsert = ""
                    sqlInsert = sqlDelete & sql & "INSERT INTO [" & sqlTableName & "] ( [PK_TBL] ," & sqlFieldName & ") " & vbCrLf & _
                                "VALUES ( '" & sAppNo & "', " & sqlFieldValue & ") ; "
                Else
                    sqlInsert = ""
                    sqlInsert = sql & "INSERT INTO [" & sqlTableName & "] ( [REF_KEY] ," & sqlFieldName & ") " & vbCrLf & _
                                "VALUES ( '" & sAppNo & "', " & sqlFieldValue & ") ; "
                End If



                'Insert data into dATAbase
                bResult = UpdateDatabase(sqlInsert)
                If Not bResult Then
                    WriteLogFile("SQL Insert", "Error during data insert into table---- " & sqlTableName, "")
                    WriteLogFile("SQL Insert", "----Error insert statement---- " & sqlInsert, "")
                End If

            End If
        Next


        Dim ReportList As Array = Split(TemplateNameList, " ")
        Dim ReportPDFList As Array = Split(PDFFileNameList, " ")
        For rn = 0 To UBound(ReportList)
            modMain.TemplateName = ""
            modMain.TemplateName = ReportList(rn)

            Dim objProcessThaiLife As New clsThaiLifeV2
            objProcessThaiLife = New clsThaiLifeV2
            objProcessThaiLife.StartProcess(ReportList(rn), ReportPDFList(rn))
            objProcessThaiLife = Nothing
        Next


        'combine combine multiple pdf


        Dim pdf As System.Diagnostics.Process
        pdf = New System.Diagnostics.Process

        Dim tempfilePath As String = ""
        Dim orifilePath As String = ""
        Dim ServerPath As String = ""

        Try
            Try
                pdf.StartInfo.UseShellExecute = True
                'pdf.StartInfo.FileName = "C:\Program Files (x86)\PDFtk\bin\pdftk.exe"
                pdf.StartInfo.FileName = "C:\Program Files\PDFtk\bin\pdftk.exe"
                'pdf.StartInfo.Arguments = TemplateList & " cat output " & modMain.PDFFilename
                pdf.StartInfo.Arguments = TemplateList & " cat output " & tempPdffilename '  modMain.PDFFilename
                pdf.StartInfo.WindowStyle = ProcessWindowStyle.Minimized
                pdf.Start()

                'wait until the process passes back an exit code
                pdf.WaitForExit()


            Catch expdf As Exception
                WriteLogFile("Shell PDFtk", "Error in starting process PDFtk", expdf.Message.ToString)

            End Try
            pdf.Dispose()
            pdf = Nothing


            'rename to ori pdf name

            tempfilePath = tempPdffilename

            orifilePath = sPdfId
            If File.Exists(tempfilePath) Then

                'check final filename, if exist then delete and generated latest copy
                If File.Exists(modMain.PDFOutput & orifilePath) Then
                    System.IO.File.Delete(modMain.PDFOutput & orifilePath)
                End If
                My.Computer.FileSystem.RenameFile(tempfilePath, orifilePath)

                'Split PDF name to create sub folder by JobId.
                Dim arrSpoolJobId As Array
                arrSpoolJobId = Split(sPdfId, "_")


                If modMain.GSBServerPath <> "" Then
                    Dim destFilePath As Array = Split(modMain.GSBServerPath.ToString, ";")
                    For cnt = 0 To UBound(destFilePath)
                        ServerPath = destFilePath(cnt)

                        If modMain.ServerPath_SubFolder.ToString = "Y" And modMain.ServerPath_SubFolderByJobId.ToString <> "Y" Then
                            ServerPath = ServerPath & Now.ToString("yyyy")
                            If Not Directory.Exists(ServerPath) Then
                                Directory.CreateDirectory(ServerPath)
                            End If
                        ElseIf modMain.ServerPath_SubFolder.ToString <> "Y" And modMain.ServerPath_SubFolderByJobId.ToString = "Y" Then
                            ServerPath = ServerPath & arrSpoolJobId(0) & "_" & arrSpoolJobId(1)
                            If Not Directory.Exists(ServerPath) Then
                                Directory.CreateDirectory(ServerPath)
                            End If
                        ElseIf modMain.ServerPath_SubFolder.ToString = "Y" And modMain.ServerPath_SubFolderByJobId.ToString = "Y" Then
                            ServerPath = ServerPath & arrSpoolJobId(0) & "_" & arrSpoolJobId(1) & "_" & Now.ToString("yyyy")
                            If Not Directory.Exists(ServerPath) Then
                                Directory.CreateDirectory(ServerPath)
                            End If
                        Else
                            If Not Directory.Exists(ServerPath) Then
                                Directory.CreateDirectory(ServerPath)
                            End If
                        End If

                        Dim DigitalSignFlag As String = ""
                        Dim SplitDestSubClassPath As String = ""
                        Dim oriServerPath As String = ""
                        DigitalSignFlag = modMain.DigitalSignFlag.ToUpper


                        If modMain.SplitBySubClassFolderFlag = "Y" Then
                            SplitDestSubClassPath = Path.Combine(ServerPath, modMain.SplitSubClassDestination)
                            oriServerPath = ServerPath
                            ServerPath = SplitDestSubClassPath
                        End If

                        If DigitalSignFlag = "Y" Then

                            If modMain.Client <> "TUI" Then

                                Call AddDigitalSign(modMain.PDFFilename, Path.Combine(ServerPath, orifilePath), sqlTableName)
                            Else

                                Dim DigitalSignTune As New ESignatureTPI
                                DigitalSignTune.SignPDF(modMain.PDFFilename, Path.Combine(ServerPath, orifilePath), modMain.CertificatePath)
                            End If



                        Else
                            My.Computer.FileSystem.CopyFile(modMain.PDFFilename, Path.Combine(ServerPath, orifilePath), True)
                            WriteLogFile("CopyFile", "Copy File to the destination path ---- " & modMain.PDFFilename & " ---- To --- " & Path.Combine(ServerPath, orifilePath), "")
                        End If



                        If modMain.SplitBySubClassFolderFlag = "Y" Then
                            ServerPath = oriServerPath
                        End If

                    Next
                End If
            Else
                WriteLogFile("Rename", "Nothing to rename. No such file ---- " & tempfilePath, "")
            End If
            'WriteLogFile("Natcha", "file to delete ---- " & TemplateList, "")
            'remove pdf file after combine
            Dim FileToDelete As Array = Split(TemplateList, " ")
            For a = 0 To UBound(FileToDelete)
                If System.IO.File.Exists(FileToDelete(a)) = True Then
                    System.IO.File.Delete(FileToDelete(a))
                    'WriteLogFile("FileToDelete", "Delete file --- " & FileToDelete(a), "")
                End If
            Next

        Catch ex As Exception
            WriteLogFile("Combine Multiple PDF", "Error in Combine Multiple PDF", ex.Message.ToString)
        End Try

        



    End Sub
    Private Sub SplitData_EVC(ByVal v_MsgBody As String)

        Dim sAppNo As String = ""
        Dim sPdfId As String = ""
        Dim sql As String = ""
        Dim sqlInsert As String = ""
        Dim sqlTableName As String
        Dim sqlFieldName As String
        Dim sqlFieldValue As String

        Dim FieldName, FieldValue As String
        Dim lFields As List(Of String)

        Dim bResult As Boolean
        Dim TemplateList As String = ""
        Dim tempPdffilename As String = ""


        Dim sRequestId As String
        sRequestId = GetGUID()

        If Not v_MsgBody.Contains(Chr(255)) Then
            WriteLogFile("Split Data", "Template Delimiter CHR(255) NOT Found ...", "")
            Exit Sub
        End If


        Dim Template As Array = Split(v_MsgBody, Chr(255))       ' for each template

        If Template.Length < 1 Then
            WriteLogFile("Split Data", "Template Delimiter CHR(255) NOT Found ...", "")
            Exit Sub
        End If


        For a As Integer = 0 To Template.Length - 1


            Select Case a
                Case 0 'key
                    'get pdfid
                    If Not Template(a).Contains(Chr(254)) Then
                        WriteLogFile("", "Field Delimiter CHR(254) NOT Found ...", "")
                        WriteLogFile("", "Error in SplitData.  Cannot get pdfid", "")
                        Exit Sub
                    End If

                    Dim sKey As Array = Split(Template(a).ToString, Chr(254))
                    If sKey.Length < 1 Then
                        WriteLogFile("", "Field Delimiter CHR(254) NOT Found ...", "")
                        WriteLogFile("", "Error in SplitData.  Cannot get pdfid", "")
                        Exit Sub
                    End If

                    If Not Template(a).Contains(Chr(253)) Then
                        WriteLogFile("", "Value Delimiter CHR(253) NOT Found ...", "")
                        WriteLogFile("", "Error in SplitData.  Cannot get pdfid", "")
                        Exit Sub
                    End If

                    Dim sKey2 As Array = Split(sKey(2).ToString, Chr(253)) 'sKey(2) store appno and pdfid
                    If sKey2.Length < 1 Then
                        WriteLogFile("", "Value Delimiter CHR(253) NOT Found ...", "")
                        WriteLogFile("", "Error in SplitData. Cannot get Appno and pdfid", "")
                        Exit Sub
                    End If

                    sAppNo = sKey2(0)
                    sPdfId = sKey2(1)

                    If sAppNo = "" Then
                        'invalid data, key not found
                        WriteLogFile("Split Data", "Error in SplitData. Key not found", "")
                        Exit For
                    End If
                    modMain.AppNo = ""
                    modMain.AppNo = sAppNo

                    'original pdffilename
                    modMain.PDFFilename = ""
                    modMain.PDFFilename = modMain.PDFOutput & sPdfId

                Case 1 'template/table 1, one side table
                    sqlFieldName = ""
                    sqlFieldValue = ""

                    If Not Template(a).Contains(Chr(254)) Then
                        WriteLogFile("", "Field Delimiter CHR(254) NOT Found ...", "")
                        WriteLogFile("", "Error in SplitData. Cannot get Template Name. Continue for Next Template", "")
                        Continue For
                    End If


                    Dim sField As Array = Split(Template(a).ToString, Chr(254))
                    If sField.Length < 1 Then
                        WriteLogFile("", "Field Delimiter CHR(254) NOT Found...", "")
                        WriteLogFile("", "Error in SplitData. Cannot get Template Name. Continue for Next Template", "")
                        Continue For
                    End If

                    'get template name/table name sField(0)
                    If Not sField(0).Contains(Chr(253)) Then
                        WriteLogFile("", "Field Delimiter CHR(253) NOT Found ...", "")
                        WriteLogFile("", "Error in SplitData. Cannot get Template Name. Continue for Next Template", "")
                        Continue For
                    End If

                    Dim sValue As Array = Split(sField(0), Chr(253))
                    If sValue.Length < 1 Then
                        WriteLogFile("", "Field Delimiter CHR(253) NOT Found...", "")
                        WriteLogFile("", "Error in SplitData. Cannot get Template Name. Continue for Next Template", "")
                        Continue For
                    End If

                    sqlTableName = sValue(0)
                    modMain.TemplateName = ""
                    modMain.TemplateName = sqlTableName
                    modMain.RequestID = sRequestId


                    tempPdffilename = modMain.PDFOutput & modMain.AppNo & "_" & modMain.TemplateName & "_" & modMain.RequestID & ".pdf"


                    'build sql stmt for insert 
                    Dim dt As System.Data.DataTable
                    Dim dc As System.Data.DataColumn
                    dt = Nothing

                    Dim fieldValues As String
                    fieldValues = ""

                    sql = "select * from [" & sqlTableName & "] where [PK_TBL] = '" & sAppNo & "'; "
                    If Not KDB.OpenRs(dt, sql, "Tbl") Then Continue For

                    lFields = New List(Of String)

                    For x As Integer = 1 To sField.Length - 1
                        Erase sValue

                        sValue = Split(sField(x), Chr(253))

                        FieldName = sValue(0)
                        FieldValue = sValue(1)

                        If Not dt.Columns.Contains(FieldName) Then Continue For
                        If lFields.Contains(FieldName) Then Continue For

                        lFields.Add(FieldName)
                        Select Case dt.Columns(FieldName).DataType.Name
                            Case "System.String", "String"
                                FieldValue = "N'" & FieldValue.Replace("'", "''") & "'"

                            Case "Boolean"
                                If sValue(1) = "True" Then
                                    FieldValue = "1"
                                Else
                                    FieldValue = "0"
                                End If

                            Case "DateTime"
                                FieldValue = "'" & CType(dt.Rows(0)(dc.ColumnName), DateTime).ToString("yyyy-MM-dd HH:mm:ss", System.Globalization.CultureInfo.InvariantCulture) & "'"

                            Case "Currency", "Decimal"
                                FieldValue = FieldValue.Replace(",", "")

                            Case Else
                        End Select

                        If sqlFieldName <> "" Then sqlFieldName &= ", "
                        sqlFieldName &= "[" & FieldName & "]"

                        If sqlFieldValue <> "" Then sqlFieldValue &= ", "
                        sqlFieldValue &= FieldValue
                    Next

                    lFields.Clear()
                    lFields = Nothing

                    sql = ""
                    If dt.Rows.Count > 0 Then
                        ' delete record
                        sql = "DELETE FROM [" & sqlTableName & "] where [PK_TBL] = '" & sAppNo & "' ; "

                        'build delete sql stmt for related table record (many side) 
                        Dim ssql As String
                        Dim dtDel As DataTable
                        Dim drDel As DataRow
                        Dim strDel As String = ""

                        dtDel = New DataTable
                        ssql = "SELECT ParentTable, ChildTable FROM [DEL_DEPENDENCIES] WHERE ParentTable = '[" & sqlTableName & "]'"
                        If KDB.OpenRs(dtDel, ssql, "DelTable") Then
                            For Each drDel In dtDel.Rows
                                strDel = ""
                                strDel = drDel.Item("ChildTable").ToString
                                sql = sql & "DELETE FROM [" & strDel & "] where [POLNBR] = '" & sAppNo & "' ; "
                            Next
                        Else

                        End If
                    End If

                    ' insert record
                    sqlInsert = ""
                    sqlInsert = sql & "INSERT INTO [" & sqlTableName & "] ( [PK_TBL] ," & sqlFieldName & ") " & vbCrLf & _
                                "VALUES ( '" & sAppNo & "', " & sqlFieldValue & ") ; "


                    bResult = UpdateDatabase(sqlInsert)
                    If Not bResult Then
                        WriteLogFile("UpdateDatabase", "Error on insert data -- " & sqlInsert, "")
                    End If

                Case Else
                    sqlFieldName = ""
                    sqlFieldValue = ""
                    If Not Template(a).Contains(Chr(254)) Then
                        WriteLogFile("", "Field Delimiter CHR(254) NOT Found ...", "")
                        WriteLogFile("", "Error in SplitData. Cannot get Template Name. Continue for Next Template", "")
                        Continue For
                    End If


                    Dim sField As Array = Split(Template(a).ToString, Chr(254))
                    If sField.Length < 1 Then
                        WriteLogFile("", "Field Delimiter CHR(254) NOT Found...", "")
                        WriteLogFile("", "Error in SplitData. Cannot get Template Name. Continue for Next Template", "")
                        Continue For
                    End If

                    'get template name/table name sField(0)
                    If Not sField(0).Contains(Chr(253)) Then
                        WriteLogFile("", "Field Delimiter CHR(253) NOT Found ...", "")
                        WriteLogFile("", "Error in SplitData. Cannot get Template Name. Continue for Next Template", "")
                        Continue For
                    End If


                    Dim sValue As Array = Split(sField(0), Chr(253))
                    If sValue.Length < 1 Then
                        WriteLogFile("", "Field Delimiter CHR(253) NOT Found...", "")
                        WriteLogFile("", "Error in SplitData. Cannot get Template Name. Continue for Next Template", "")
                        Continue For
                    End If

                    sqlTableName = sValue(0)

                    Dim dt As System.Data.DataTable
                    Dim dc As System.Data.DataColumn
                    dt = Nothing

                    Dim fieldValues As String
                    fieldValues = ""

                    sql = "select * from [" & sqlTableName & "] where [POLNBR] = '" & sAppNo & "'; "
                    If Not KDB.OpenRs(dt, sql, "Tbl") Then Continue For



                    lFields = New List(Of String)

                    For x As Integer = 1 To sField.Length - 1
                        Erase sValue

                        sValue = Split(sField(x), Chr(253))

                        FieldName = sValue(0)
                        FieldValue = sValue(1)


                        If Not dt.Columns.Contains(FieldName) Then Continue For
                        If lFields.Contains(FieldName) Then Continue For

                        lFields.Add(FieldName)
                        Select Case dt.Columns(FieldName).DataType.Name
                            Case "System.String", "String"
                                FieldValue = "N'" & FieldValue.Replace("'", "''") & "'"

                            Case "Boolean"
                                If sValue(1) = "True" Then
                                    FieldValue = "1"
                                Else
                                    FieldValue = "0"
                                End If

                            Case "DateTime"
                                FieldValue = "'" & CType(dt.Rows(0)(dc.ColumnName), DateTime).ToString("yyyy-MM-dd HH:mm:ss", System.Globalization.CultureInfo.InvariantCulture) & "'"

                            Case "Currency", "Decimal"
                                FieldValue = FieldValue.Replace(",", "")

                            Case Else
                        End Select

                        If sqlFieldName <> "" Then sqlFieldName &= ", "
                        sqlFieldName &= "[" & FieldName & "]"

                        If sqlFieldValue <> "" Then sqlFieldValue &= ", "
                        sqlFieldValue &= FieldValue
                    Next

                    lFields.Clear()
                    lFields = Nothing

                    sql = ""

                    ' insert record
                    sqlInsert = ""

                    sqlInsert = sql & "INSERT INTO [" & sqlTableName & "] (" & sqlFieldName & ") " & vbCrLf & _
                               "VALUES (" & sqlFieldValue & ") ; "


                    bResult = UpdateDatabase(sqlInsert)

                    If Not bResult Then
                        WriteLogFile("UpdateDatabase", "Error on insert data -- " & sqlInsert, "")
                    End If
            End Select
        Next


        If bResult Then
            'print pdf
            Dim objProcessThaiLife As New clsThaiLife
            objProcessThaiLife = New clsThaiLife
            objProcessThaiLife.StartProcess()
            objProcessThaiLife = Nothing
        End If



        Try

            'rename to ori pdf name
            Dim tempfilePath As String = ""
            Dim orifilePath As String = ""
            Dim ServerPath As String = ""
            tempfilePath = tempPdffilename

            orifilePath = sPdfId ' modMain.PDFFilename
            If File.Exists(tempfilePath) Then

                ' Give a new name
                My.Computer.FileSystem.RenameFile(tempfilePath, orifilePath)
                If modMain.GSBServerPath <> "" Then
                    Dim destFilePath As Array = Split(modMain.GSBServerPath.ToString, ";")
                    For cnt = 0 To UBound(destFilePath)
                        ServerPath = destFilePath(cnt)
                        System.IO.File.Copy(modMain.PDFFilename, ServerPath & orifilePath)

                    Next
                End If
            Else
                WriteLogFile("Rename", "Nothing to rename. No such file ---- " & tempfilePath, "")
            End If

        Catch ex As Exception
            WriteLogFile("Combine Multiple PDF", "Error in Combine Multiple PDF", ex.Message.ToString)
        End Try



    End Sub

    Private Sub BatchPrinting(ByVal strBatchBodyMsg As String)

        WriteLogFile("Split Data => ", "Proceed to Batch Printing processing ...", "")

        Dim sBatchNo As String = ""
        Dim sBatchPdfId As String = ""
        Dim BatchTemplateList As String = ""
        Dim tempBatchPdffilename As String = ""
        Dim PDFFixformPath As String = ""



        Dim sRequestId As String
        sRequestId = GetGUID()


        Dim App As Array = Split(strBatchBodyMsg, Chr(252)) 'AppNo delimiter

        For z As Integer = 0 To App.Length - 1

            If z = 0 Then 'store batch id and batch pdf filename

                Dim sBatchKey As Array = Split(App(z).ToString, Chr(255))
                If sBatchKey.Length < 1 Then
                    WriteLogFile("", "Field Delimiter CHR(255) NOT Found ...", "")
                    WriteLogFile("", "Error in SplitData. Cannot get BatchId and BatchPDFid", "")
                    Exit Sub
                End If

                sBatchNo = sBatchKey(0)
                sBatchPdfId = sBatchKey(1)

                If sBatchNo = "" Then
                    'invalid data, key not found
                    WriteLogFile("Split Data", "Error in SplitData. Batch Key not found", "")
                    Exit For
                End If

                tempBatchPdffilename = modMain.PDFOutput & sRequestId & "tmp" & sBatchPdfId

            Else


                '##################
                Dim sAppNo As String = ""
                Dim stmpAppNo As String = ""
                Dim sPdfId As String = ""
                Dim sql As String = ""
                Dim sqlInsert As String = ""
                Dim sqlTableName As String
                Dim sqlFieldName As String
                Dim sqlFieldValue As String

                Dim FieldName, FieldValue As String
                Dim lFields As List(Of String)

                Dim bResult As Boolean
                Dim TemplateList As String = ""
                Dim tempPdffilename As String = ""

                Dim Template As Array = Split(App(z).ToString, Chr(255))       ' for each template

                If Template.Length < 1 Then
                    WriteLogFile("Split Data", "Template Delimiter CHR(255) NOT Found ...", "")
                    Exit Sub
                End If


                For a As Integer = 0 To Template.Length - 1

                    If a = 0 Then

                        Dim sKey As Array = Split(Template(a).ToString, Chr(254))
                        If sKey.Length < 1 Then
                            WriteLogFile("", "Field Delimiter CHR(254) NOT Found ...", "")
                            WriteLogFile("", "Error in SplitData.  Cannot get Appno and pdfid", "")
                            Continue For
                        End If

                        Dim sKey2 As Array = Split(sKey(2).ToString, Chr(253)) 'sKey(2) store appno, pdfid
                        If sKey2.Length < 1 Then
                            WriteLogFile("", "Value Delimiter CHR(253) NOT Found ...", "")
                            WriteLogFile("", "Error in SplitData. Cannot get Appno and pdfid", "")
                            Continue For
                        End If

                        sAppNo = sKey2(0)
                        sPdfId = sKey2(1)

                        If sAppNo = "" Then
                            'invalid data, key not found
                            WriteLogFile("Split Data", "Error in SplitData. Key not found", "")
                            Exit For
                        End If
                        modMain.AppNo = ""
                        modMain.AppNo = sAppNo


                        stmpAppNo = ""
                        stmpAppNo = sAppNo

                        'original pdffilename
                        modMain.PDFFilename = ""
                        modMain.PDFFilename = modMain.PDFOutput & sPdfId

                        'introduce requestid on 20161214 to solve same message for multiple EXE running at the same time
                        tempPdffilename = modMain.PDFOutput & sRequestId & "tmp" & sPdfId


                        'Store batchTemplateList 
                        If BatchTemplateList <> "" Then
                            BatchTemplateList = BatchTemplateList & " " & modMain.PDFOutput & sRequestId & sPdfId
                        Else
                            BatchTemplateList = modMain.PDFOutput & sRequestId & sPdfId
                        End If
                    Else
                        sqlFieldName = ""
                        sqlFieldValue = ""
                        Dim sField As Array = Split(Template(a), Chr(254))

                        sAppNo = stmpAppNo & "-" & a
                        modMain.AppNo = sAppNo
                        If sField.Length < 1 Then
                            WriteLogFile("", "Field Delimiter CHR(254) NOT Found...", "")
                            WriteLogFile("", "Error in SplitData. Cannot get Template Name. Continue for Next Template", "")
                            Continue For
                        End If

                        'get template name/table name sField(0)
                        Dim sValue As Array = Split(sField(0), Chr(253))    ' for each field value in template
                        If sValue.Length < 1 Then
                            WriteLogFile("", "Field Delimiter CHR(253) NOT Found...", "")
                            WriteLogFile("", "Error in SplitData. Cannot get Template Name. Continue for Next Template", "")
                            Continue For
                        End If

                        sqlTableName = sValue(0)
                        modMain.TemplateName = ""
                        modMain.TemplateName = sqlTableName
                        modMain.RequestID = sRequestId


                        If TemplateList <> "" Then

                            TemplateList = TemplateList & " " & modMain.PDFOutput & modMain.AppNo & "_" & modMain.TemplateName & "_" & modMain.RequestID & ".pdf"
                        Else

                            TemplateList = modMain.PDFOutput & modMain.AppNo & "_" & modMain.TemplateName & "_" & modMain.RequestID & ".pdf"
                        End If

                        Dim sourcePath As String = ""
                        If Not sqlTableName.Contains("_") Then GoTo Cont 'assumption made that fix pdf must have underscore in template name

                        Dim FixFormName As Array = Split(sqlTableName.ToUpper, "_")


                        If CheckPDFFixForm(modMain.Client, FixFormName(0), sourcePath) Then

                            Dim sourceFilename As String = ""
                            Dim destFilename As String = ""

                            'sourcePath = sField(1)
                            sourcePath = sourcePath.Trim
                            If Not sourcePath.EndsWith("\") Then
                                sourcePath &= "\"
                            End If

                            sourceFilename = sourcePath & sqlTableName & ".pdf"
                            destFilename = modMain.PDFOutput & modMain.AppNo & "_" & modMain.TemplateName & "_" & modMain.RequestID & ".pdf"
                            'check file exist
                            If System.IO.File.Exists(sourceFilename) = True Then

                                Try
                                    'copy and rename as  modMain.AppNo & "_" & modMain.TemplateName & ".pdf"
                                    My.Computer.FileSystem.CopyFile(sourceFilename, destFilename, True)
                                Catch ex As Exception
                                    WriteLogFile("CopyFile", "Error on Copy file -- " & ex.Message, "")
                                End Try
                            Else
                                WriteLogFile("CopyFile", "Error in copy file. " & sourceFilename & " does not exist.", "")
                            End If
                            Continue For
                        End If


Cont:
                        Dim dt As System.Data.DataTable
                        Dim dc As System.Data.DataColumn
                        dt = Nothing


                        Dim fieldValues As String

                        fieldValues = ""
                       

                        sql = "select * from [" & sqlTableName & "] where [PK_TBL] = '" & sAppNo & "'; "
                        If Not KDB.OpenRs(dt, sql, "Tbl") Then Continue For



                        lFields = New List(Of String)

                        For x As Integer = 1 To sField.Length - 1
                            Erase sValue
                            sValue = Split(sField(x), Chr(253))

                            FieldName = sValue(0)
                            FieldValue = sValue(1)

                            'if database structure do not have such field then continue next
                            If Not dt.Columns.Contains(FieldName) Then Continue For
                            'if text file contain than duplicate field name then continue next
                            If lFields.Contains(FieldName) Then Continue For

                            lFields.Add(FieldName)
                            Select Case dt.Columns(FieldName).DataType.Name
                                Case "System.String", "String"
                                    FieldValue = "N'" & FieldValue.Replace("'", "''") & "'"

                                Case "Boolean"
                                    If sValue(1) = "True" Then
                                        FieldValue = "1"
                                    Else
                                        FieldValue = "0"
                                    End If

                                Case "DateTime"
                                    FieldValue = "'" & CType(dt.Rows(0)(dc.ColumnName), DateTime).ToString("yyyy-MM-dd HH:mm:ss", System.Globalization.CultureInfo.InvariantCulture) & "'"

                                Case "Currency", "Decimal"
                                    FieldValue = FieldValue.Replace(",", "")

                                Case Else
                            End Select

                            If sqlFieldName <> "" Then sqlFieldName &= ", "
                            sqlFieldName &= "[" & FieldName & "]"

                            If sqlFieldValue <> "" Then sqlFieldValue &= ", "
                            sqlFieldValue &= FieldValue
                        Next

                        lFields.Clear()
                        lFields = Nothing

                        sql = ""
                        If dt.Rows.Count > 0 Then
                            ' delete record
                            sql = "DELETE FROM [" & sqlTableName & "] where [PK_TBL] = '" & sAppNo & "' ; "
                        End If

                        ' insert record
                        sqlInsert = ""
                        sqlInsert = sql & "INSERT INTO [" & sqlTableName & "] ( [PK_TBL] ," & sqlFieldName & ") " & vbCrLf & _
                                    "VALUES ( '" & sAppNo & "', " & sqlFieldValue & ") ; "

                        'Insert data into dATAbase
                        bResult = UpdateDatabase(sqlInsert)

                        If bResult Then
                            'print pdf
                            Dim objProcessThaiLife As New clsThaiLife
                            objProcessThaiLife = New clsThaiLife
                            objProcessThaiLife.StartProcess()
                            objProcessThaiLife = Nothing

                        End If
                    End If
                Next



                Call MergePDF(TemplateList, tempPdffilename, sRequestId & sPdfId)
                '##################


            End If
        Next

        Call BatchMergePDF(BatchTemplateList, tempBatchPdffilename, sBatchPdfId)

        Dim sourcefile As String = ""
        Dim destinationfile As String = ""
        sourcefile = modMain.PDFOutput & sBatchPdfId


        If File.Exists(sourcefile) Then
            If modMain.GSBServerPath <> "" Then
                Dim destFilePath As Array = Split(modMain.GSBServerPath.ToString, ";") 'GSBServerPath store another server
                For cnt = 0 To UBound(destFilePath)
                    destinationfile = destFilePath(cnt) & sBatchPdfId
                    My.Computer.FileSystem.CopyFile(sourcefile, destinationfile, True)

                Next
            End If
        End If

    End Sub
    Private Sub BatchPrintingSign(ByVal strBatchBodyMsg As String)

        WriteLogFile("Split Data => ", "Proceed to Batch Printing processing ...", "")

        Dim sBatchNo As String = ""
        Dim sBatchPdfId As String = ""
        Dim BatchTemplateList As String = ""
        Dim tempBatchPdffilename As String = ""
        Dim PDFFixformPath As String = ""
        Dim sqlTableName As String


        Dim sRequestId As String
        sRequestId = GetGUID()


        Dim App As Array = Split(strBatchBodyMsg, Chr(252)) 'AppNo delimiter

        For z As Integer = 0 To App.Length - 1

            If z = 0 Then 'store batch id and batch pdf filename

                Dim sBatchKey As Array = Split(App(z).ToString, Chr(255))
                If sBatchKey.Length < 1 Then
                    WriteLogFile("", "Field Delimiter CHR(255) NOT Found ...", "")
                    WriteLogFile("", "Error in SplitData. Cannot get BatchId and BatchPDFid", "")
                    Exit Sub
                End If

                sBatchNo = sBatchKey(0)
                sBatchPdfId = sBatchKey(1)

                If sBatchNo = "" Then
                    'invalid data, key not found
                    WriteLogFile("Split Data", "Error in SplitData. Batch Key not found", "")
                    Exit For
                End If

                tempBatchPdffilename = modMain.PDFOutput & sRequestId & "tmp" & sBatchPdfId

            Else

                '##################
                Dim sAppNo As String = ""
                Dim stmpAppNo As String = ""
                Dim sPdfId As String = ""
                Dim sql As String = ""
                Dim sqlInsert As String = ""

                Dim sqlFieldName As String
                Dim sqlFieldValue As String

                Dim FieldName, FieldValue As String
                Dim lFields As List(Of String)

                Dim bResult As Boolean
                Dim TemplateList As String = ""
                Dim tempPdffilename As String = ""

                Dim Template As Array = Split(App(z).ToString, Chr(255))       ' for each template

                If Template.Length < 1 Then
                    WriteLogFile("Split Data", "Template Delimiter CHR(255) NOT Found ...", "")
                    Exit Sub
                End If



                For a As Integer = 0 To Template.Length - 1


                    If a = 0 Then
                        'get appno, pdfid

                        Dim sKey As Array = Split(Template(a).ToString, Chr(254))
                        If sKey.Length < 1 Then
                            WriteLogFile("", "Field Delimiter CHR(254) NOT Found ...", "")
                            WriteLogFile("", "Error in SplitData.  Cannot get Appno and pdfid", "")
                            Continue For
                        End If

                        Dim sKey2 As Array = Split(sKey(2).ToString, Chr(253)) 'sKey(2) store appno, pdfid
                        If sKey2.Length < 1 Then
                            WriteLogFile("", "Value Delimiter CHR(253) NOT Found ...", "")
                            WriteLogFile("", "Error in SplitData. Cannot get Appno and pdfid", "")
                            Continue For
                        End If

                        sAppNo = sKey2(0)
                        sPdfId = sKey2(1)

                        If sAppNo = "" Then
                            'invalid data, key not found
                            WriteLogFile("Split Data", "Error in SplitData. Key not found", "")
                            Exit For
                        End If
                        modMain.AppNo = ""
                        modMain.AppNo = sAppNo


                        stmpAppNo = ""
                        stmpAppNo = sAppNo

                        'original pdffilename
                        modMain.PDFFilename = ""
                        modMain.PDFFilename = modMain.PDFOutput & sPdfId

                        tempPdffilename = modMain.PDFOutput & sRequestId & "tmp" & sPdfId


                        'Store batchTemplateList 
                        If BatchTemplateList <> "" Then
                            BatchTemplateList = BatchTemplateList & " " & modMain.PDFOutput & sRequestId & sPdfId
                        Else
                            BatchTemplateList = modMain.PDFOutput & sRequestId & sPdfId
                        End If
                    Else
                        sqlFieldName = ""
                        sqlFieldValue = ""
                        Dim sField As Array = Split(Template(a), Chr(254))

                        sAppNo = stmpAppNo & "-" & a
                        modMain.AppNo = sAppNo
                        If sField.Length < 1 Then
                            WriteLogFile("", "Field Delimiter CHR(254) NOT Found...", "")
                            WriteLogFile("", "Error in SplitData. Cannot get Template Name. Continue for Next Template", "")
                            Continue For
                        End If

                        'get template name/table name sField(0)
                        Dim sValue As Array = Split(sField(0), Chr(253))
                        If sValue.Length < 1 Then
                            WriteLogFile("", "Field Delimiter CHR(253) NOT Found...", "")
                            WriteLogFile("", "Error in SplitData. Cannot get Template Name. Continue for Next Template", "")
                            Continue For
                        End If

                        sqlTableName = sValue(0)
                        modMain.TemplateName = ""
                        modMain.TemplateName = sqlTableName
                        modMain.RequestID = sRequestId


                        If TemplateList <> "" Then
                            TemplateList = TemplateList & " " & modMain.PDFOutput & modMain.AppNo & "_" & modMain.TemplateName & "_" & modMain.RequestID & ".pdf"
                        Else
                            TemplateList = modMain.PDFOutput & modMain.AppNo & "_" & modMain.TemplateName & "_" & modMain.RequestID & ".pdf"
                        End If

                        Dim sourcePath As String = ""
                        If Not sqlTableName.Contains("_") Then GoTo Cont

                        Dim FixFormName As Array = Split(sqlTableName.ToUpper, "_")

                        If CheckPDFFixForm(modMain.Client, FixFormName(0), sourcePath) Then
                            Dim sourceFilename As String = ""
                            Dim destFilename As String = ""

                            'sourcePath = sField(1)
                            sourcePath = sourcePath.Trim
                            If Not sourcePath.EndsWith("\") Then
                                sourcePath &= "\"
                            End If

                            sourceFilename = sourcePath & sqlTableName & ".pdf"
                            destFilename = modMain.PDFOutput & modMain.AppNo & "_" & modMain.TemplateName & "_" & modMain.RequestID & ".pdf"
                            'check file exist
                            If System.IO.File.Exists(sourceFilename) = True Then

                                Try
                                    My.Computer.FileSystem.CopyFile(sourceFilename, destFilename, True)
                                Catch ex As Exception
                                    WriteLogFile("CopyFile", "Error on Copy file -- " & ex.Message, "")
                                End Try
                            Else
                                WriteLogFile("CopyFile", "Error in copy file. " & sourceFilename & " does not exist.", "")
                            End If
                            Continue For
                        End If


Cont:
                        Dim dt As System.Data.DataTable
                        Dim dc As System.Data.DataColumn
                        dt = Nothing


                        Dim fieldValues As String

                        fieldValues = ""


                        sql = "select * from [" & sqlTableName & "] where [PK_TBL] = '" & sAppNo & "'; "
                        If Not KDB.OpenRs(dt, sql, "Tbl") Then Continue For

                        lFields = New List(Of String)

                        For x As Integer = 1 To sField.Length - 1
                            Erase sValue
                            sValue = Split(sField(x), Chr(253))

                            FieldName = sValue(0)
                            FieldValue = sValue(1)

                            'if database structure do not have such field then continue next
                            If Not dt.Columns.Contains(FieldName) Then Continue For
                            'if text file contain than duplicate field name then continue next
                            If lFields.Contains(FieldName) Then Continue For

                            lFields.Add(FieldName)
                            Select Case dt.Columns(FieldName).DataType.Name
                                Case "System.String", "String"
                                    FieldValue = "N'" & FieldValue.Replace("'", "''") & "'"

                                Case "Boolean"
                                    If sValue(1) = "True" Then
                                        FieldValue = "1"
                                    Else
                                        FieldValue = "0"
                                    End If

                                Case "DateTime"
                                    FieldValue = "'" & CType(dt.Rows(0)(dc.ColumnName), DateTime).ToString("yyyy-MM-dd HH:mm:ss", System.Globalization.CultureInfo.InvariantCulture) & "'"

                                Case "Currency", "Decimal"
                                    FieldValue = FieldValue.Replace(",", "")

                                Case Else
                            End Select

                            If sqlFieldName <> "" Then sqlFieldName &= ", "
                            sqlFieldName &= "[" & FieldName & "]"

                            If sqlFieldValue <> "" Then sqlFieldValue &= ", "
                            sqlFieldValue &= FieldValue
                        Next

                        lFields.Clear()
                        lFields = Nothing

                        sql = ""
                        If dt.Rows.Count > 0 Then
                            ' delete record
                            sql = "DELETE FROM [" & sqlTableName & "] where [PK_TBL] = '" & sAppNo & "' ; "
                        End If

                        ' insert record
                        sqlInsert = ""
                        sqlInsert = sql & "INSERT INTO [" & sqlTableName & "] ( [PK_TBL] ," & sqlFieldName & ") " & vbCrLf & _
                                    "VALUES ( '" & sAppNo & "', " & sqlFieldValue & ") ; "


                        bResult = UpdateDatabase(sqlInsert)

                        If bResult Then
                            'print pdf
                            Dim objProcessThaiLife As New clsThaiLife
                            objProcessThaiLife = New clsThaiLife
                            objProcessThaiLife.StartProcess()
                            objProcessThaiLife = Nothing

                        End If
                    End If
                Next

                Call MergePDF(TemplateList, tempPdffilename, sRequestId & sPdfId)
                '##################


            End If
        Next

        Call BatchMergePDF(BatchTemplateList, tempBatchPdffilename, sBatchPdfId)

        Dim sourcefile As String = ""
        Dim destinationfile As String = ""
        sourcefile = modMain.PDFOutput & sBatchPdfId


        If File.Exists(sourcefile) Then
            If modMain.GSBServerPath <> "" Then
                Dim destFilePath As Array = Split(modMain.GSBServerPath.ToString, ";")
                For cnt = 0 To UBound(destFilePath)
                    destinationfile = destFilePath(cnt) & sBatchPdfId



                    Dim DigitalSignFlag As String = ""
                    DigitalSignFlag = modMain.DigitalSignFlag.ToUpper
                    If DigitalSignFlag = "Y" Then
                        Call AddDigitalSign(sourcefile, destinationfile, sqlTableName)
                    Else
                        My.Computer.FileSystem.CopyFile(sourcefile, destinationfile, True)
                        WriteLogFile("CopyFile", "Copy File to the destination path ---- " & sourcefile & " ---- To --- " & destinationfile, "")
                    End If

                Next
            End If
        End If

    End Sub
    Private Sub BatchPrintingV2(ByVal strBatchBodyMsg As String)

        WriteLogFile("Split Data => ", "Proceed to Batch Printing processing ...", "")

        Dim sBatchNo As String = ""
        Dim sBatchPdfId As String = ""
        Dim BatchTemplateList As String = ""
        Dim tempBatchPdffilename As String = ""
        Dim PDFFixformPath As String = ""
        Dim sqlTableName As String


        Dim sRequestId As String
        sRequestId = GetGUID()
        modMain.RequestID = sRequestId

        Dim App As Array = Split(strBatchBodyMsg, Chr(252)) 'AppNo delimiter

        For z As Integer = 0 To App.Length - 1

            If z = 0 Then 'store batch id and batch pdf filename

                Dim sBatchKey As Array = Split(App(z).ToString, Chr(255))
                If sBatchKey.Length < 1 Then
                    WriteLogFile("", "Field Delimiter CHR(255) NOT Found ...", "")
                    WriteLogFile("", "Error in SplitData. Cannot get BatchId and BatchPDFid", "")
                    Exit Sub
                End If

                sBatchNo = sBatchKey(0)
                sBatchPdfId = sBatchKey(1)

                If sBatchNo = "" Then
                    'invalid data, key not found
                    WriteLogFile("Split Data", "Error in SplitData. Batch Key not found", "")
                    Exit For
                End If

                tempBatchPdffilename = modMain.PDFOutput & sRequestId & "tmp" & sBatchPdfId

            Else

                '##################
                Dim sAppNo As String = ""
                Dim stmpAppNo As String = ""
                Dim sPdfId As String = ""
                Dim sql As String = ""
                Dim sqlInsert As String = ""
                Dim sqlDelete As String = ""

                Dim sqlTableInd As String '--M as Main Table (parent), C as child Table
                Dim sqlFieldName As String
                Dim sqlFieldValue As String

                Dim FieldName, FieldValue As String
                Dim lFields As List(Of String)

                Dim bResult As Boolean
                Dim TemplateList As String = ""
                Dim AppNoList As String = ""
                Dim TemplateNameList As String = ""
                Dim PDFFileNameList As String = ""
                Dim tempPdffilename As String = ""

                Dim Template As Array = Split(App(z).ToString, Chr(255))       ' for each template

                If Template.Length < 1 Then
                    WriteLogFile("Split Data", "Template Delimiter CHR(255) NOT Found ...", "")
                    Exit Sub
                End If


                For a As Integer = 0 To Template.Length - 1

                    If a = 0 Then

                        Dim sKey As Array = Split(Template(a).ToString, Chr(254))
                        If sKey.Length < 1 Then
                            WriteLogFile("", "Field Delimiter CHR(254) NOT Found ...", "")
                            WriteLogFile("", "Error in SplitData.  Cannot get Appno and pdfid", "")
                            Continue For
                        End If

                        Dim sKey2 As Array = Split(sKey(2).ToString, Chr(253)) 'sKey(2) store appno, pdfid
                        If sKey2.Length < 1 Then
                            WriteLogFile("", "Value Delimiter CHR(253) NOT Found ...", "")
                            WriteLogFile("", "Error in SplitData. Cannot get Appno and pdfid", "")
                            Continue For
                        End If

                        sAppNo = sKey2(0)
                        sPdfId = sKey2(1)


                        If sAppNo = "" Then
                            'invalid data, key not found
                            WriteLogFile("Split Data", "Error in SplitData. Key not found", "")
                            Exit For
                        End If


                        If modMain.SplitBySubClassFolderFlag = "Y" Then
                            Dim arrAppno As String()
                            arrAppno = sAppNo.Split("_")
                            modMain.SplitSubClassDestination = arrAppno(arrAppno.Length - 1)
                        End If
                        '====================================================================================================



                        modMain.AppNo = ""
                        modMain.AppNo = sAppNo


                        stmpAppNo = ""
                        stmpAppNo = sAppNo

                        'original pdffilename
                        modMain.PDFFilename = ""
                        modMain.PDFFilename = modMain.PDFOutput & sPdfId


                        tempPdffilename = modMain.PDFOutput & sRequestId & "tmp" & sPdfId


                        'Store batchTemplateList 
                        If BatchTemplateList <> "" Then
                            BatchTemplateList = BatchTemplateList & " " & modMain.PDFOutput & sRequestId & sPdfId
                        Else
                            BatchTemplateList = modMain.PDFOutput & sRequestId & sPdfId
                        End If
                    Else
                        sqlFieldName = ""
                        sqlFieldValue = ""
                        Dim sField As Array = Split(Template(a), Chr(254))

                        sAppNo = stmpAppNo & "-" & a
                        modMain.AppNo = sAppNo
                        If sField.Length < 1 Then
                            WriteLogFile("", "Field Delimiter CHR(254) NOT Found...", "")
                            WriteLogFile("", "Error in SplitData. Cannot get Template Name. Continue for Next Template", "")
                            Continue For
                        End If

                        'get template name/table name sField(0)
                        Dim sValue As Array = Split(sField(0), Chr(253))    ' for each field value in template
                        If sValue.Length < 1 Then
                            WriteLogFile("", "Field Delimiter CHR(253) NOT Found...", "")
                            WriteLogFile("", "Error in SplitData. Cannot get Template Name. Continue for Next Template", "")
                            Continue For
                        End If

                        sqlTableName = sValue(0)
                        sqlTableInd = sValue(1) '--M as Main Table (parent), C as child Table


                        If sqlTableInd = "M" Or sqlTableInd = "1" Then
                            If TemplateList <> "" Then

                                TemplateList = TemplateList & " " & modMain.PDFOutput & modMain.AppNo & "_" & sqlTableName & "_" & modMain.RequestID & ".pdf"
                            Else

                                TemplateList = modMain.PDFOutput & modMain.AppNo & "_" & sqlTableName & "_" & modMain.RequestID & ".pdf"
                            End If

                            'create a list to call ssrs report after data insert into sql 
                            If Not sqlTableName.Contains("_") Then
                                If AppNoList <> "" Then
                                    AppNoList = AppNoList & " " & sAppNo
                                Else
                                    AppNoList = sAppNo
                                End If

                                If TemplateNameList <> "" Then
                                    TemplateNameList = TemplateNameList & " " & sqlTableName
                                Else
                                    TemplateNameList = sqlTableName
                                End If

                                If PDFFileNameList <> "" Then
                                    PDFFileNameList = PDFFileNameList & " " & modMain.PDFOutput & modMain.AppNo & "_" & sqlTableName & "_" & modMain.RequestID & ".pdf"
                                Else
                                    PDFFileNameList = modMain.PDFOutput & modMain.AppNo & "_" & sqlTableName & "_" & modMain.RequestID & ".pdf"
                                End If
                            End If
                        End If



                        Dim sourcePath As String = ""
                        If Not sqlTableName.Contains("_") Then GoTo Cont 

                        Dim FixFormName As Array = Split(sqlTableName.ToUpper, "_")


                        If CheckPDFFixForm(modMain.Client, FixFormName(0), sourcePath) Then

                            Dim sourceFilename As String = ""
                            Dim destFilename As String = ""

                            'sourcePath = sField(1)
                            sourcePath = sourcePath.Trim
                            If Not sourcePath.EndsWith("\") Then
                                sourcePath &= "\"
                            End If

                            sourceFilename = sourcePath & sqlTableName & ".pdf"
                            destFilename = modMain.PDFOutput & modMain.AppNo & "_" & sqlTableName & "_" & modMain.RequestID & ".pdf"
                            'check file exist
                            If System.IO.File.Exists(sourceFilename) = True Then

                                Try
                                    'copy and rename as  modMain.AppNo & "_" & modMain.TemplateName & ".pdf"
                                    My.Computer.FileSystem.CopyFile(sourceFilename, destFilename, True)
                                Catch ex As Exception
                                    WriteLogFile("CopyFile", "Error on Copy file -- " & ex.Message, "")
                                End Try
                            Else
                                WriteLogFile("CopyFile", "Error in copy file. " & sourceFilename & " does not exist.", "")
                            End If
                            Continue For
                        End If


Cont:
                        Dim dt As System.Data.DataTable
                        Dim dc As System.Data.DataColumn
                        dt = Nothing


                        Dim fieldValues As String

                        fieldValues = ""

                        If sqlTableInd = "M" Or sqlTableInd = "1" Then
                            sql = "select * from [" & sqlTableName & "] where [PK_TBL] = '" & sAppNo & "'; "
                        Else
                            sql = "select * from [" & sqlTableName & "]; "
                        End If


                        If Not KDB.OpenRs(dt, sql, "Tbl") Then Continue For

                        lFields = New List(Of String)

                        For x As Integer = 1 To sField.Length - 1 'start at sField(1) because sField(0) is templatename/tablename
                            Erase sValue
                            sValue = Split(sField(x), Chr(253))

                            FieldName = sValue(0)
                            FieldValue = sValue(1)


                            If Not dt.Columns.Contains(FieldName) Then Continue For

                            If lFields.Contains(FieldName) Then Continue For

                            lFields.Add(FieldName)
                            Select Case dt.Columns(FieldName).DataType.Name
                                Case "System.String", "String"
                                    FieldValue = "N'" & FieldValue.Replace("'", "''") & "'"

                                Case "Boolean"
                                    If sValue(1) = "True" Then
                                        FieldValue = "1"
                                    Else
                                        FieldValue = "0"
                                    End If

                                Case "DateTime"
                                    FieldValue = "'" & CType(dt.Rows(0)(dc.ColumnName), DateTime).ToString("yyyy-MM-dd HH:mm:ss", System.Globalization.CultureInfo.InvariantCulture) & "'"

                                Case "Currency", "Decimal"
                                    FieldValue = FieldValue.Replace(",", "")

                                Case Else
                            End Select

                            If sqlFieldName <> "" Then sqlFieldName &= ", "
                            sqlFieldName &= "[" & FieldName & "]"

                            If sqlFieldValue <> "" Then sqlFieldValue &= ", "
                            sqlFieldValue &= FieldValue
                        Next

                        lFields.Clear()
                        lFields = Nothing


                        If sqlTableInd = "M" Or sqlTableInd = "1" Then
                            sql = ""
                            If dt.Rows.Count > 0 Then
                                ' delete record
                                sql = "DELETE FROM [" & sqlTableName & "] where [PK_TBL] = '" & sAppNo & "' ; "

                                'delete the child table data as well

                                Dim ssql As String
                                Dim dtDel As DataTable
                                Dim drDel As DataRow
                                Dim strDel As String = ""

                                dtDel = New DataTable
                                ssql = "SELECT ParentTable, ChildTable FROM [DEL_DEPENDENCIES] WHERE ParentTable = '[" & sqlTableName & "]'"
                                If KDB.OpenRs(dtDel, ssql, "DelTable") Then
                                    For Each drDel In dtDel.Rows
                                        strDel = ""
                                        strDel = drDel.Item("ChildTable").ToString
                                        sqlDelete = sqlDelete & "DELETE FROM [" & strDel & "] where [REF_KEY] = '" & sAppNo & "' ; "
                                    Next
                                Else
                                    WriteLogFile("SQL Insert", "Error during select ---- " & ssql, "")
                                End If
                            End If

                            sqlInsert = ""
                            sqlInsert = sqlDelete & sql & "INSERT INTO [" & sqlTableName & "] ( [PK_TBL] ," & sqlFieldName & ") " & vbCrLf & _
                                        "VALUES ( '" & sAppNo & "', " & sqlFieldValue & ") ; "
                        Else
                            sqlInsert = ""
                            sqlInsert = sql & "INSERT INTO [" & sqlTableName & "] ( [REF_KEY] ," & sqlFieldName & ") " & vbCrLf & _
                                        "VALUES ( '" & sAppNo & "', " & sqlFieldValue & ") ; "
                        End If


                        bResult = UpdateDatabase(sqlInsert)
                        If Not bResult Then
                            WriteLogFile("SQL Insert", "Error during data insert into table---- " & sqlTableName, "")
                            WriteLogFile("SQL Insert", "----Error insert statement---- " & sqlInsert, "")
                        End If


                    End If
                Next 'multiple pdf per appno


                'loop the call report 
                Dim AppList As Array = Split(AppNoList, " ")
                Dim ReportList As Array = Split(TemplateNameList, " ")
                Dim ReportPDFList As Array = Split(PDFFileNameList, " ")
                For rn = 0 To UBound(ReportList)

                    modMain.AppNo = ""
                    modMain.AppNo = AppList(rn)

                    modMain.TemplateName = ""
                    modMain.TemplateName = ReportList(rn)

                    Dim objProcessThaiLife As New clsThaiLifeV2
                    objProcessThaiLife = New clsThaiLifeV2
                    objProcessThaiLife.StartProcess(ReportList(rn), ReportPDFList(rn))
                    objProcessThaiLife = Nothing
                Next

                Call MergePDF(TemplateList, tempPdffilename, sRequestId & sPdfId)
                '##################


            End If
        Next


        Call BatchMergePDF(BatchTemplateList, tempBatchPdffilename, sBatchPdfId)


        Dim sourcefile As String = ""
        Dim destinationfile As String = ""
        sourcefile = modMain.PDFOutput & sBatchPdfId

        'Define array for subfolder name by job id.
        Dim arrBatchPdfId As Array
        arrBatchPdfId = Split(sBatchPdfId, "_")


        If File.Exists(sourcefile) Then
            If modMain.GSBServerPath <> "" Then
                Dim destFilePath As Array = Split(modMain.GSBServerPath.ToString, ";")
                For cnt = 0 To UBound(destFilePath)

                    destinationfile = destFilePath(cnt)

                    If modMain.ServerPath_SubFolder.ToString = "Y" And modMain.ServerPath_SubFolderByJobId.ToString <> "Y" Then
                        destinationfile = destinationfile & Now.ToString("yyyy")
                        If Not Directory.Exists(destinationfile) Then
                            Directory.CreateDirectory(destinationfile)
                        End If
                    ElseIf modMain.ServerPath_SubFolder.ToString <> "Y" And modMain.ServerPath_SubFolderByJobId.ToString = "Y" Then
                        destinationfile = destinationfile & arrBatchPdfId(0) & "_" & arrBatchPdfId(1)
                        If Not Directory.Exists(destinationfile) Then
                            Directory.CreateDirectory(destinationfile)
                        End If
                    ElseIf modMain.ServerPath_SubFolder.ToString = "Y" And modMain.ServerPath_SubFolderByJobId.ToString = "Y" Then
                        destinationfile = destinationfile & arrBatchPdfId(0) & "_" & arrBatchPdfId(1) & "_" & Now.ToString("yyyy")
                        If Not Directory.Exists(destinationfile) Then
                            Directory.CreateDirectory(destinationfile)
                        End If
                    Else
                        If Not Directory.Exists(destinationfile) Then
                            Directory.CreateDirectory(destinationfile)
                        End If
                    End If


                    Dim DigitalSignFlag As String = ""
                    Dim SplitDestSubClassPath As String = ""
                    Dim oriServerPath As String = ""
                    DigitalSignFlag = modMain.DigitalSignFlag.ToUpper



                    If modMain.SplitBySubClassFolderFlag = "Y" Then
                        SplitDestSubClassPath = Path.Combine(destinationfile, modMain.SplitSubClassDestination)
                        oriServerPath = destinationfile
                        destinationfile = SplitDestSubClassPath
                    End If




                    If DigitalSignFlag = "Y" Then
                        If modMain.Client <> "TUI" Then
                            Call AddDigitalSign(sourcefile, Path.Combine(destinationfile, sBatchPdfId), sqlTableName)
                        Else
                            Dim DigitalSignTune As New ESignatureTPI
                            DigitalSignTune.SignPDF(sourcefile, Path.Combine(destinationfile, sBatchPdfId), modMain.CertificatePath)
                        End If

                    Else
                        My.Computer.FileSystem.CopyFile(sourcefile, Path.Combine(destinationfile, sBatchPdfId), True)
                        WriteLogFile("CopyFile", "Copy File to the destination path ---- " & sourcefile & " ---- To --- " & Path.Combine(destinationfile, sBatchPdfId), "")

                    End If


                    If modMain.SplitBySubClassFolderFlag = "Y" Then
                        destinationfile = oriServerPath
                    End If


                Next
            End If
        End If
    End Sub
    Private Sub MergePDF(ByVal lTemplate As String, _
                         ByVal strOutputFilename As String,
                         ByVal strRenameOutputName As String)

        Dim pdf As System.Diagnostics.Process
        pdf = New System.Diagnostics.Process

        Try

            Try
                pdf.StartInfo.UseShellExecute = True
                'pdf.StartInfo.FileName = "C:\Program Files (x86)\PDFtk\bin\pdftk.exe"
                pdf.StartInfo.FileName = "C:\Program Files\PDFtk\bin\pdftk.exe"
                pdf.StartInfo.Arguments = lTemplate & " cat output " & strOutputFilename
                pdf.StartInfo.WindowStyle = ProcessWindowStyle.Minimized
                pdf.Start()

                'wait until the process passes back an exit code
                pdf.WaitForExit()

                'free resource associated with this process

            Catch expdf As Exception
                WriteLogFile("Shell PDFtk", "Error in starting process PDFtk", expdf.Message.ToString)
                'pdf.Kill()
            End Try
            pdf.Dispose()
            pdf = Nothing

            ' Give a new name
            If File.Exists(strOutputFilename) Then
                'check final filename, if exist then delete and generated latest copy
                If File.Exists(modMain.PDFOutput & strRenameOutputName) Then
                    System.IO.File.Delete(modMain.PDFOutput & strRenameOutputName)
                End If
                My.Computer.FileSystem.RenameFile(strOutputFilename, strRenameOutputName)

            Else
                WriteLogFile("Rename", "Nothing to rename. No such file ---- " & strOutputFilename, "")
            End If

            'remove pdf file after combine
            Dim FileToDelete As Array = Split(lTemplate, " ")
            For a = 0 To UBound(FileToDelete)
                If System.IO.File.Exists(FileToDelete(a)) = True Then
                    System.IO.File.Delete(FileToDelete(a))

                End If
            Next

        Catch ex As Exception
            WriteLogFile("Combine Multiple PDF", "Error in Combine Multiple PDF", ex.Message.ToString)
        End Try


    End Sub
    Private Sub SplitData_Oper(ByVal v_MsgBody As String)

        If Not v_MsgBody.Contains("|") Then

            WriteLogFile("Erorr Split Data", "Delimiter '|' not Found ...", "")

            Exit Sub
        End If

        Dim abc As Array = Split(v_MsgBody, "|")       ' for each template

        If abc.Length < 1 Then
            WriteLogFile("Split Data", "Template Delimiter '|' NOT Found ...", "")
            Exit Sub
        End If

        'ReportName|0001
        Dim rptname As String = ""
        Dim dtkey As String = ""
        Dim printername As String = ""

        For a As Integer = 0 To abc.Length - 1
            Select Case a
                Case 0
                    rptname = abc(a) ' ReportName
                Case 1
                    dtkey = abc(a) '0001
                Case 2
                    printername = abc(a)
                Case Else
            End Select
        Next

        If printername.Trim = "" Then
            WriteLogFile("Split Data", "Printer Name Not specific. Program Stop", "")
            Exit Sub
        End If



        Dim pdfoutput As String = ""
        pdfoutput = modMain.PDFOutput & rptname & "_" & dtkey & ".pdf"

        'call ssrs u need to call cls
        Dim result As Boolean = False
        Dim objProcessOper As New clsOper
        objProcessOper = New clsOper
        result = objProcessOper.StartProcess(rptname, dtkey, pdfoutput)
        objProcessOper = Nothing

        If result Then
            'send file to printer
            Try

                Dim fileName As String
                fileName = pdfoutput
                If File.Exists(fileName) Then

                    'print your file 

                    If PrintOnSelectedPrinter(fileName, printername) Then
                        WriteLogFile("Print File Succeed", "Your print file success sent to printer...", "")
                    Else
                        WriteLogFile("Print File Error", "Your print file Failed send to printer...", "")
                    End If
                End If
            Catch ex As Exception
                WriteLogFile("File Printing", "Error in File Printing", ex.Message.ToString)
            End Try
        End If
    End Sub

    
    Private Sub MergePDF(ByVal lTemplate As String, _
                        ByVal strOutputFilename As String)


        Dim pdf As System.Diagnostics.Process
        pdf = New System.Diagnostics.Process

        Try

            Try
                pdf.StartInfo.UseShellExecute = True
                'pdf.StartInfo.FileName = "C:\Program Files (x86)\PDFtk\bin\pdftk.exe"
                pdf.StartInfo.FileName = "C:\Program Files\PDFtk\bin\pdftk.exe"
                pdf.StartInfo.Arguments = lTemplate & " cat output " & strOutputFilename
                pdf.StartInfo.WindowStyle = ProcessWindowStyle.Minimized
                pdf.Start()

                'wait until the process passes back an exit code
                pdf.WaitForExit()



            Catch expdf As Exception
                WriteLogFile("Shell PDFtk", "Error in starting process PDFtk", expdf.Message.ToString)

            End Try
            pdf.Dispose()
            pdf = Nothing


            'remove pdf file after combine
            Dim FileToDelete As Array = Split(lTemplate, " ")
            For a = 0 To UBound(FileToDelete)
                If System.IO.File.Exists(FileToDelete(a)) = True Then
                    System.IO.File.Delete(FileToDelete(a))

                End If
            Next

        Catch ex As Exception
            WriteLogFile("Combine Multiple PDF", "Error in Combine Multiple PDF", ex.Message.ToString)
        End Try


    End Sub

    Private Sub ExtractXMLValue(ByVal v_Params As String, ByRef strProgID As String, ByRef strPDFFilename As String)
        Dim m_xmld As System.Xml.XmlDocument
        Dim m_nodelist As System.Xml.XmlNodeList

        Dim paramName As String
        Dim paramValue As String

        strProgID = ""
        strPDFFilename = ""


        'Create the XML Document
        m_xmld = New System.Xml.XmlDocument()

        'Load the Xml file
        m_xmld.Load(New System.IO.StringReader(v_Params))
        Try
            'Get the list of name nodes 
            m_nodelist = m_xmld.SelectNodes("/parameters")

            'Loop through the nodes
            For Each m_node In m_nodelist
                For a As Integer = 0 To m_node.ChildNodes.Count - 1
                    With m_node.ChildNodes.Item(a)
                        paramName = .Name
                        paramValue = .InnerText.Trim
                    End With

                    Select Case paramName.ToUpper
                        Case "ProgId".ToUpper
                            strProgID = paramValue
                        Case "PdfFilename".ToUpper
                            strPDFFilename = paramValue

                    End Select
                Next
            Next

        Catch ex As Exception
            WriteLogFile("ExtractXMLValue", "Error parsing parameters", ex.Message.ToString)
            Return
        End Try

        m_nodelist = Nothing
        m_xmld = Nothing
    End Sub


    Private Function UpdateDatabase(ByVal strSQL As String) As Boolean

        Dim blnResult As Boolean = True
        Dim sqlCmd As SqlClient.SqlCommand


        If strSQL <> "" Then
            sqlCmd = New SqlClient.SqlCommand(strSQL, sqlconn)
            Try
                sqlCmd.ExecuteNonQuery()
            Catch ex As Exception
                WriteLogFile("UpdateDatabase", "Error in updating database -" & vbCrLf & strSQL & " ", ex.Message.ToString)
                blnResult = False
            End Try
        End If

ExitFunc:
        If sqlCmd IsNot Nothing Then sqlCmd.Dispose()
        sqlCmd = Nothing


        Return blnResult
    End Function
    Private Sub RollBackMessage(ByVal strLabel As String, ByVal strBody As String)
        Dim qMsg As New Message
        Dim qTrn As MessageQueueTransaction

        qTrn = New MessageQueueTransaction

        qMsg.Label = strLabel
        qMsg.Body = strBody
        qTrn.Begin()
        Try
            qMain.Send(qMsg, qTrn)
            qTrn.Commit()
            WriteLogFile("RollBackMessage", strLabel & " : " & strBody, "")
        Catch ex As Exception
            qTrn.Abort()
            WriteLogFile("RollBackMessage", "unable to rollback message", ex.Message.ToUpper)
        End Try

        If qTrn IsNot Nothing Then qTrn.Dispose()
        If qMsg IsNot Nothing Then qMsg.Dispose()

        qTrn = Nothing
        qMsg = Nothing

    End Sub

    Private Sub ReadXML()
        Dim rawData As String = _
            "<Products>" & _
            "  <Product>" & _
            "    <name>Name 1</name>" & _
            "    <Id>101</Id>" & _
            "    <quantity>10</quantity>" & _
            "  </Product>" & _
            "  <Product>" & _
            "    <name>Name 2</name>" & _
            "    <Id>102</Id>" & _
            "    <quantity>10</quantity>" & _
            "  </Product>" & _
            "</Products>"

        Dim xmlDoc As New XmlDocument
        Dim productNodes As XmlNodeList
        Dim productNode As XmlNode
        Dim baseDataNodes As XmlNodeList
        Dim bFirstInRow As Boolean

        xmlDoc.LoadXml(rawData)

        productNodes = xmlDoc.GetElementsByTagName("Product")
        For Each productNode In productNodes
            baseDataNodes = productNode.ChildNodes
            bFirstInRow = True
            For Each baseDataNode As XmlNode In baseDataNodes
                If (bFirstInRow) Then
                    bFirstInRow = False
                Else
                    Console.Write(", ")
                End If
                Console.Write(baseDataNode.Name & ": " & baseDataNode.InnerText)
            Next
        Next
    End Sub

    Private Sub ReadXML_v2()

        Dim rawData As String = _
            "<?xml version='1.0'?>" & _
            "<Books>" & _
            "    <Book>" & _
            "        <Title>Beginning XML</Title>" & _
            "        <Publisher>Wrox</Publisher>" & _
            "    </Book>" & _
            "    <Book>" & _
            "        <Title>XML Step by Step</Title>" & _
            "        <Publisher>MSPress</Publisher>" & _
            "    </Book>" & _
            "    <Book>" & _
            "       <Title>Professional XML</Title>" & _
            "        <Publisher>Wrox</Publisher>" & _
            "    </Book>" & _
            "    <Book>" & _
            "        <Title>Developing XML solutions</Title>" & _
            "        <Publisher>MSPress</Publisher>" & _
            "    </Book>" & _
            "</Books>"



        'Instantiate an XmlDocument object.
        Dim xmldoc As New System.Xml.XmlDocument()

        'Load Books.xml into the DOM.
        xmldoc.LoadXml(rawData)

        Dim MSPressBookList As System.Xml.XmlNodeList
        Dim MSPressBook As System.Xml.XmlNode


        MSPressBookList = xmldoc.SelectNodes("//Publisher[. = 'MSPress']/parent::node()/Title")

        System.Diagnostics.Debug.WriteLine("Books published by MSPress...")
        System.Diagnostics.Debug.WriteLine("**************************...")

        'Use an XmlNode object to iterate through the XmlNodeList that SelectNodes returns.
        For Each MSPressBook In MSPressBookList
            System.Diagnostics.Debug.WriteLine(MSPressBook.InnerText)
        Next

        System.Diagnostics.Debug.WriteLine(vbCrLf & "Looking for the title 'XML Step by Step'...")
        System.Diagnostics.Debug.WriteLine("***************************************...")


        Dim bookNode As System.Xml.XmlNode = xmldoc.SelectSingleNode("//Title[.='XML Step by Step']")

        'Determine whether a matching node is located. 
        If Not bookNode Is Nothing Then
            System.Diagnostics.Debug.WriteLine("Located title 'XML Step by Step'")
        Else
            System.Diagnostics.Debug.WriteLine("Could not locate title 'XML Step by Step'")
        End If

    End Sub

    Private Function CheckPDFFixForm(ByVal strClient As String, _
                                     ByVal strForm As String, _
                                     ByRef strFormPath As String) As Boolean


        Dim blnResult As Boolean = False


        If strForm = "" Then Return blnResult

        Dim Ssql As String = ""
        Dim mdtForm As New DataTable
        Dim str_Form As String = ""
        Dim str_FormPath As String = ""

        Ssql = "SELECT Client, PDFFormName, PDFFormPath " & _
            "FROM PDFFixForm " & _
            "WHERE Client = '" & strClient & "' AND PDFFormName = '" & strForm & "'"

        If Not KDB.OpenRs(mdtForm, Ssql, "Client_PDFFixForm") Then
            If Not KDB.GetLastException Is Nothing Then
                logWriter.WriteLine("")
                WriteLogFile("Client_PDFFixForm", "Error in calling Client_PDFFixForm", KDB.GetLastException.Message.ToString)
                logWriter.WriteLine("")
            End If
        End If

        If mdtForm Is Nothing Then GoTo ExitFunc

        If mdtForm.Rows.Count > 0 Then

            str_Form = "" & mdtForm.Rows(0).Item("PDFFormName")
            str_FormPath = "" & mdtForm.Rows(0).Item("PDFFormPath")
            strFormPath = str_FormPath

            blnResult = True
        End If

        If Not mdtForm Is Nothing Then mdtForm.Dispose()
        mdtForm = Nothing

ExitFunc:

        Return blnResult
    End Function

    Private Sub BatchMergePDF(ByVal pdflist As String, _
                ByVal strOutputFilename As String, _
                ByVal strRenameOutputName As String)



        Dim lenCnt As Integer = 0
        Dim lenTemp As Integer = 0
        Dim mList As String = ""


        lenCnt = Len(pdflist)

        If lenCnt < 1500 Then
            'go to merge straight away
            MergePDF(pdflist, strOutputFilename, strRenameOutputName)
        Else

            Dim Template As Array = Split(pdflist.ToString, " ")
            lenCnt = 0 'restart to 0 
            For a As Integer = 0 To Template.Length - 1

                If lenCnt = 0 Then
                    lenCnt = Len(Template(a))
                Else
                    lenCnt = lenCnt + Len(Template(a)) + 1 '+1 = space between the template list
                End If


                If lenCnt > 1500 Then

                    Dim tmpOutputFN As String = ""
                    tmpOutputFN = modMain.PDFOutput & a & "_" & strRenameOutputName

                    MergePDF(mList, tmpOutputFN)

                    'take out the record that exceed len 2000
                    a = a - 1
                    'restart at 0
                    lenCnt = 0
                    'add the merged filename length
                    lenCnt = Len(tmpOutputFN)

                    'reset merge list
                    mList = ""
                    'add the merged filename into new list
                    mList = tmpOutputFN
                    GoTo NextRec

                End If

                'build the merge list
                If mList = "" Then
                    mList = Template(a)
                Else
                    mList = mList & " " & Template(a)
                End If


                If a = Template.Length - 1 Then 'last record
                    'send to merge
                    MergePDF(mList, strOutputFilename, strRenameOutputName)
                End If
NextRec:
            Next

        End If
    End Sub

    Public Function GetGUID() As String
        Dim g As Guid

        g = Guid.NewGuid()


        Return System.DateTime.Now.ToString("yyyyMMddHHmmssfff") & Microsoft.VisualBasic.Right(g.ToString, 3)

    End Function
   
    Public Function PrintFile(ByVal fileName As String, _
                              printerSetting As System.Drawing.Printing.PrinterSettings) As Boolean

        Dim printProcess As System.Diagnostics.Process = Nothing
        Dim printed As Boolean = False


        Try

            If printerSetting IsNot Nothing Then

                Dim startInfo As New ProcessStartInfo()
                Dim aa As String = ""

                startInfo.Verb = "Print"
                startInfo.Arguments = printerSetting.PrinterName     ' <----default printer to use---- i
                startInfo.FileName = fileName
                startInfo.UseShellExecute = True
                startInfo.CreateNoWindow = True
                startInfo.WindowStyle = ProcessWindowStyle.Hidden

                Using print As System.Diagnostics.Process = Process.Start(startInfo)

                    'Close the application after X milliseconds with WaitForExit(X)   

                    print.WaitForExit(10000)

                    If print.HasExited = False Then

                        If print.CloseMainWindow() Then
                            printed = True
                        Else
                            printed = True
                        End If

                    Else
                        printed = True

                    End If


                    aa = print.ProcessName
                    print.Close()
                    print.Dispose()

                End Using

                If Not aa = "" Then
                    Dim procesos As Process()
                    procesos = Process.GetProcessesByName(aa)

                    If procesos.Length > 0 Then

                        For i = procesos.Length - 1 To 0 Step -1
                            If Not procesos(i).HasExited Then
                                procesos(i).Kill()
                            End If
                        Next
                    End If
                End If


            Else
                Throw New Exception("Printers not found in the system...")
            End If


        Catch ex As Exception
            Throw
            'MsgBox(ex.Message.ToString)
        End Try

        Return printed

    End Function
    Public Function PrintOnSelectedPrinter(ByVal fileName As String, selectedprinter As String) As Boolean
        'added on 2018-04-10
        Dim printed As Boolean = False
        Dim pathToExecutable As String = "AcroRd32.exe"
        Dim sReport = fileName
        Dim SPrinter = selectedprinter

        Try
            Dim starter As New ProcessStartInfo(pathToExecutable, "/t " + sReport + " " + SPrinter + "")
            starter.UseShellExecute = True
            starter.CreateNoWindow = True
            starter.WindowStyle = ProcessWindowStyle.Hidden

            Dim Print As New Process()
            Print.StartInfo = starter
            Print.Start()
            Print.WaitForExit(10000)

            Dim iLoop As Int16 = 0
            'check the process has exited or not
            If Print.HasExited = False Then

                If Print.CloseMainWindow() Then
                    printed = True
                Else
                    printed = True
                End If

            Else
                printed = True
            End If

            Print.Close()
            Print.Dispose()
            Print = Nothing
            starter = Nothing

            Dim procesos As Process()
            procesos = Process.GetProcessesByName("AcroRd32")

            If procesos.Length > 0 Then
                For i = procesos.Length - 1 To 0 Step -1
                    If Not procesos(i).HasExited Then
                        procesos(i).Kill()
                    End If
                Next
            End If
        Catch ex As Exception
            Throw
        End Try

        Return printed
    End Function
End Class
